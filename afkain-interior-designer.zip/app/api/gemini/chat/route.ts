import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

// Access the environment variable. It is a server-side secret.
const apiKey = process.env.GEMINI_API_KEY;

// Lazy initialize client to prevent startup failure if key is missing
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing. Please add it to your environment secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json(
        { error: "Invalid messages array provided." },
        { status: 400 }
      );
    }

    const ai = getAiClient();

    // Map client-side message structure to Gemini API structure
    const systemInstruction = 
      "You are 'Aria', the elite Lead AI Interior Stylist at 'Afkain Interior Designer', " +
      "Ahmedabad's premier luxury interior and exterior design studio.\n\n" +
      "YOUR DETAILS:\n" +
      "- Studio: Afkain Interior Designer\n" +
      "- Rating: 5.0 ★ (98+ reviews)\n" +
      "- Location: Gomtipur, Ahmedabad, Gujarat 380021\n" +
      "- Phone: 084880 95593\n" +
      "- Packages:\n" +
      "  * 1 BHK Interior Package – ₹3,50,000\n" +
      "  * 2 BHK Interior Package – ₹4,80,000\n" +
      "  * 3 BHK Interior Package – ₹6,00,000\n" +
      "  All packages include: Custom Space Layout, Realistic 3D Visuals, Premium Material Procurement, Dedicated Site Supervision, and Complete Turnkey Installation Support.\n" +
      "- Key Services:\n" +
      "  * Interior Design (Modular Kitchens, Living Rooms, Bedrooms, Wardrobes)\n" +
      "  * Exterior Design (Facade, Elevation, Landscaping)\n" +
      "  * Commercial Offices & Showrooms\n" +
      "  * Full Structural Building Design, Renovation, and Remodeling\n\n" +
      "YOUR STYLE & TONE:\n" +
      "- You have a sophisticated, warm, and highly passionate designer persona.\n" +
      "- You paint pictures with words: reference textures (reclaimed walnut, linen, ribbed plaster), light (warm natural light, directional sconces), and palettes (terracotta, charcoal black, off-white, forest green).\n" +
      "- Speak with authority and warmth. Encourage the client to seek a free professional consultation.\n" +
      "- Give tailored, exciting suggestions about their spaces. For instance, if they ask about a living room, suggest incorporating a feature wall with organic symmetry and warm lighting accents.\n" +
      "- Keep your responses elegant, informative, and structurally beautiful (using markdown bulletin elements). Keep responses under 200 words to ensure snappy UI interaction.";

    // Map history and final message
    const formattedContents = messages.map((m: any) => ({
      role: m.role === "assistant" ? "model" : m.role,
      parts: [{ text: m.content }],
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return NextResponse.json({
      role: "assistant",
      content: response.text || "I apologize, but I struggled to envision that concept clearly. Could we refine your space goals?",
    });

  } catch (error: any) {
    console.error("Gemini Route Error:", error);
    return NextResponse.json(
      { error: error?.message || "An error occurred with our design engine." },
      { status: 500 }
    );
  }
}
