const categoryImages = {
  Burgers: "images/burger.png",
  Pizza: "images/pizza.png",
  Bowls: "images/bowl.png",
  Pasta: "images/pasta.png",
  Desserts: "images/dessert.png",
  Drinks: "images/drink.png"
};

const state = {
  menu: [],
  cart: JSON.parse(localStorage.getItem("zoopyFoodCart") || "{}"),
  category: "All",
  search: "",
  user: null
};

const $ = (selector) => document.querySelector(selector);
const money = (value) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(value);
const menuGrid = $("#menuGrid");
const categoryList = $("#categoryList");
const cartDrawer = $("#cartDrawer");
const overlay = $("#overlay");
const checkoutModal = $("#checkoutModal");
let toastTimer;

function totals() {
  const subtotal = state.menu.reduce((sum, item) => sum + item.price * (state.cart[item.id] || 0), 0);
  const deliveryFee = subtotal === 0 || subtotal >= 35 ? 0 : 3.99;
  const serviceFee = subtotal * 0.05;
  return { subtotal, deliveryFee, serviceFee, total: subtotal + deliveryFee + serviceFee };
}

function saveCart() {
  localStorage.setItem("zoopyFoodCart", JSON.stringify(state.cart));
  renderCart();
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

function renderCategories() {
  const categories = ["All"].concat([...new Set(state.menu.map((item) => item.category))]);
  categoryList.innerHTML = categories.map((category) =>
    '<button class="category-button ' + (state.category === category ? "active" : "") +
    '" data-category="' + category + '">' + category + '</button>'
  ).join("");
}

function renderMenu() {
  const query = state.search.toLowerCase();
  const filtered = state.menu.filter((item) => {
    const matchesCategory = state.category === "All" || item.category === state.category;
    const searchable = (item.name + " " + item.description + " " + item.category).toLowerCase();
    return matchesCategory && searchable.includes(query);
  });
  $("#resultCount").textContent = filtered.length + (filtered.length === 1 ? " dish" : " dishes") + " ready to order";
  $("#clearFilters").hidden = state.category === "All" && !state.search;
  $("#emptyResults").hidden = filtered.length > 0;
  menuGrid.hidden = filtered.length === 0;
  menuGrid.innerHTML = filtered.map((item) =>
    '<article class="food-card">' +
      '<div class="food-art"><img class="food-photo" src="' + categoryImages[item.category] + '" alt="' + item.name + '" loading="lazy"><span class="food-badge">' + item.badge + '</span></div>' +
      '<div class="food-info"><div class="food-meta"><span>★ ' + item.rating + '</span><span>◷ ' + item.time + '</span><span>' + item.category + '</span></div>' +
      '<h3>' + item.name + '</h3><p>' + item.description + '</p>' +
      '<div class="food-bottom"><strong class="food-price">' + money(item.price) + '</strong><button class="add-button" data-add="' + item.id + '" aria-label="Add ' + item.name + ' to cart">+</button></div></div>' +
    '</article>'
  ).join("");
}

function renderCart() {
  const entries = state.menu.filter((item) => state.cart[item.id] > 0);
  const count = entries.reduce((sum, item) => sum + state.cart[item.id], 0);
  $("#cartCount").textContent = count;
  $("#cartEmpty").hidden = entries.length > 0;
  $("#cartSummary").hidden = entries.length === 0;
  $("#cartItems").innerHTML = entries.map((item) =>
    '<div class="cart-item"><div class="cart-item-art" style="background:' + item.color + '">' + item.emoji + '</div>' +
      '<div><h4>' + item.name + '</h4><p>' + money(item.price) + ' each</p><div class="quantity"><button data-change="' + item.id + '" data-delta="-1" aria-label="Remove one">−</button><strong>' + state.cart[item.id] + '</strong><button data-change="' + item.id + '" data-delta="1" aria-label="Add one">+</button></div></div>' +
      '<button class="remove-item" data-remove="' + item.id + '" aria-label="Remove ' + item.name + '">×</button></div>'
  ).join("");
  const summary = totals();
  $("#subtotal").textContent = money(summary.subtotal);
  $("#deliveryFee").textContent = summary.deliveryFee ? money(summary.deliveryFee) : "Free";
  $("#serviceFee").textContent = money(summary.serviceFee);
  $("#cartTotal").textContent = money(summary.total);
  $("#checkoutTotal").textContent = money(summary.total);
  $("#deliveryHint").textContent = summary.subtotal > 0 && summary.subtotal < 35 ? "· " + money(35 - summary.subtotal) + " to free" : "";
}

function openCart() {
  overlay.hidden = false;
  requestAnimationFrame(() => cartDrawer.classList.add("open"));
  cartDrawer.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  $("#closeCart").focus();
}

function closeCart() {
  cartDrawer.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  setTimeout(() => { if (!cartDrawer.classList.contains("open")) overlay.hidden = true; }, 350);
}

function addToCart(id) {
  state.cart[id] = Math.min((state.cart[id] || 0) + 1, 20);
  saveCart();
  const item = state.menu.find((entry) => entry.id === id);
  showToast(item.name + " added to your basket");
}

async function loadMenu() {
  try {
    const response = await fetch("/api/menu");
    if (!response.ok) throw new Error("Menu unavailable");
    state.menu = await response.json();
    renderCategories();
    renderMenu();
    renderCart();
  } catch (error) {
    $("#resultCount").textContent = "We could not load the menu.";
    $("#emptyResults").hidden = false;
    menuGrid.hidden = true;
  }
}

menuGrid.addEventListener("click", (event) => {
  const button = event.target.closest("[data-add]");
  if (button) addToCart(Number(button.dataset.add));
});

categoryList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  state.category = button.dataset.category;
  renderCategories();
  renderMenu();
});

$("#searchInput").addEventListener("input", (event) => {
  state.search = event.target.value.trim();
  renderMenu();
});

$("#clearFilters").addEventListener("click", () => {
  state.category = "All";
  state.search = "";
  $("#searchInput").value = "";
  renderCategories();
  renderMenu();
});

$("#cartItems").addEventListener("click", (event) => {
  const change = event.target.closest("[data-change]");
  const remove = event.target.closest("[data-remove]");
  if (change) {
    const id = Number(change.dataset.change);
    state.cart[id] = (state.cart[id] || 0) + Number(change.dataset.delta);
    if (state.cart[id] <= 0) delete state.cart[id];
    if (state.cart[id] > 20) state.cart[id] = 20;
    saveCart();
  }
  if (remove) {
    delete state.cart[Number(remove.dataset.remove)];
    saveCart();
  }
});

$("#cartTrigger").addEventListener("click", openCart);
$("#closeCart").addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);
$("#browseButton").addEventListener("click", () => { closeCart(); $("#menu").scrollIntoView(); });
$("#checkoutButton").addEventListener("click", () => {
  if (!Object.values(state.cart).some((quantity) => quantity > 0)) return;
  closeCart();
  $("#checkoutContent").hidden = false;
  $("#successState").hidden = true;
  $("#formError").textContent = "";
  checkoutModal.showModal();
});
$("#closeCheckout").addEventListener("click", () => checkoutModal.close());
$("#doneButton").addEventListener("click", () => { checkoutModal.close(); $("#menu").scrollIntoView(); });

$("#checkoutForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;
  const button = $("#placeOrderButton");
  const data = new FormData(form);
  const payload = {
    customer: {
      name: data.get("name"), email: data.get("email"), phone: data.get("phone"),
      address: data.get("address"), city: data.get("city"), postalCode: data.get("postalCode")
    },
    notes: data.get("notes"),
    paymentMethod: data.get("paymentMethod"),
    items: Object.entries(state.cart).filter((entry) => entry[1] > 0).map((entry) => ({ id: Number(entry[0]), quantity: entry[1] }))
  };
  button.disabled = true;
  button.innerHTML = "Placing your order…";
  $("#formError").textContent = "";
  try {
    const response = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Could not place your order.");
    state.cart = {};
    saveCart();
    form.reset();
    $("#orderNumber").textContent = result.order.id;
    $("#checkoutContent").hidden = true;
    $("#successState").hidden = false;
  } catch (error) {
    $("#formError").textContent = error.message;
  } finally {
    button.disabled = false;
    button.innerHTML = "Place my order <span>→</span>";
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && cartDrawer.classList.contains("open")) closeCart();
});

loadMenu();


function updateAuthUI() {
  const signedIn = Boolean(state.user);
  $("#authGuest").hidden = signedIn;
  $("#authUser").hidden = !signedIn;
  $("#accountLabel").textContent = signedIn ? state.user.name.split(" ")[0] : "Log in";
  if (signedIn) {
    $("#accountName").textContent = state.user.name.split(" ")[0];
    $("#accountEmail").textContent = state.user.email;
    $("#accountAvatar").textContent = state.user.name.charAt(0).toUpperCase();
  }
}

function setAuthMode(mode) {
  const login = mode === "login";
  $("#loginForm").hidden = !login;
  $("#registerForm").hidden = login;
  $("#loginTab").classList.toggle("active", login);
  $("#registerTab").classList.toggle("active", !login);
  $("#authTitle").textContent = login ? "Welcome back." : "Join the table.";
  $("#loginError").textContent = "";
  $("#registerError").textContent = "";
}

async function loadAuth() {
  try {
    const response = await fetch("/api/auth/me");
    const result = await response.json();
    state.user = result.user;
  } catch {
    state.user = null;
  }
  updateAuthUI();
}

async function submitAuth(form, endpoint, errorSelector) {
  const button = form.querySelector('button[type="submit"]');
  const original = button.innerHTML;
  const data = Object.fromEntries(new FormData(form));
  button.disabled = true;
  button.textContent = endpoint === "login" ? "Logging in…" : "Creating account…";
  $(errorSelector).textContent = "";
  try {
    const response = await fetch("/api/auth/" + endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Something went wrong.");
    state.user = result.user;
    updateAuthUI();
    form.reset();
    showToast(endpoint === "login" ? "Welcome back, " + state.user.name.split(" ")[0] : "Your Zoopy account is ready");
  } catch (error) {
    $(errorSelector).textContent = error.message;
  } finally {
    button.disabled = false;
    button.innerHTML = original;
  }
}

$("#accountTrigger").addEventListener("click", () => {
  updateAuthUI();
  $("#authModal").showModal();
});
$("#closeAuth").addEventListener("click", () => $("#authModal").close());
$("#loginTab").addEventListener("click", () => setAuthMode("login"));
$("#registerTab").addEventListener("click", () => setAuthMode("register"));
$("#loginForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitAuth(event.currentTarget, "login", "#loginError");
});
$("#registerForm").addEventListener("submit", (event) => {
  event.preventDefault();
  submitAuth(event.currentTarget, "register", "#registerError");
});
$("#logoutButton").addEventListener("click", async () => {
  await fetch("/api/auth/logout", { method: "POST" });
  state.user = null;
  updateAuthUI();
  setAuthMode("login");
  $("#authModal").close();
  showToast("You’re logged out");
});
$("#checkoutButton").addEventListener("click", () => {
  if (!state.user) return;
  const form = $("#checkoutForm");
  if (!form.elements.name.value) form.elements.name.value = state.user.name;
  if (!form.elements.email.value) form.elements.email.value = state.user.email;
});

loadAuth();

