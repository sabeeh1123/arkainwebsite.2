require("dotenv").config();

const express = require("express");
const path = require("path");
const crypto = require("crypto");
const { promisify } = require("util");
const { Pool } = require("pg");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const DATABASE_URL = process.env.DATABASE_URL;
const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: false } : false
});

const scrypt = promisify(crypto.scrypt);
const menu = [
  { id: 1, name: "Smoky Harvest Burger", description: "Charred beef, smoked cheddar, onion jam, pickles and house sauce.", price: 14.5, category: "Burgers", rating: 4.9, time: "20–25 min", emoji: "🍔", badge: "Bestseller", color: "#f4b34e" },
  { id: 2, name: "Firecracker Chicken", description: "Crispy chicken, hot honey glaze, crunchy slaw and cooling ranch.", price: 13, category: "Burgers", rating: 4.8, time: "20–25 min", emoji: "🍗", badge: "Spicy", color: "#ef7b5a" },
  { id: 3, name: "Garden Pesto Pizza", description: "Basil pesto, roasted tomatoes, zucchini ribbons and fresh mozzarella.", price: 16.5, category: "Pizza", rating: 4.7, time: "25–30 min", emoji: "🍕", badge: "Vegetarian", color: "#87a96b" },
  { id: 4, name: "Midnight Margherita", description: "San Marzano tomato, fior di latte, basil and extra-virgin olive oil.", price: 15, category: "Pizza", rating: 4.9, time: "25–30 min", emoji: "🍕", badge: "Classic", color: "#dd6b55" },
  { id: 5, name: "Citrus Salmon Bowl", description: "Miso salmon, sesame rice, avocado, edamame and citrus ponzu.", price: 18.5, category: "Bowls", rating: 4.8, time: "20–25 min", emoji: "🥗", badge: "High protein", color: "#6ca69b" },
  { id: 6, name: "Crispy Tofu Crunch", description: "Ginger tofu, brown rice, cucumber, cabbage and peanut dressing.", price: 14, category: "Bowls", rating: 4.6, time: "15–20 min", emoji: "🥢", badge: "Vegan", color: "#b49b65" },
  { id: 7, name: "Truffle Tagliatelle", description: "Silky mushroom cream, parmesan, cracked pepper and truffle oil.", price: 17, category: "Pasta", rating: 4.9, time: "25–30 min", emoji: "🍝", badge: "Chef's pick", color: "#a88769" },
  { id: 8, name: "Sunset Arrabbiata", description: "Rigatoni, slow-cooked tomato, Calabrian chilli and pecorino.", price: 14.5, category: "Pasta", rating: 4.7, time: "20–25 min", emoji: "🍝", badge: "Spicy", color: "#ce7058" },
  { id: 9, name: "Salted Caramel Cloud", description: "Warm chocolate cake, caramel center and vanilla bean cream.", price: 8.5, category: "Desserts", rating: 4.9, time: "10–15 min", emoji: "🍰", badge: "Sweet finish", color: "#b78373" },
  { id: 10, name: "Berry Cheesecake Jar", description: "Whipped cheesecake, berry compote and buttery biscuit crumble.", price: 7.5, category: "Desserts", rating: 4.8, time: "10–15 min", emoji: "🫐", badge: "New", color: "#987c9e" },
  { id: 11, name: "Ginger Lime Fizz", description: "Fresh lime, ginger, mint and sparkling water over crushed ice.", price: 5, category: "Drinks", rating: 4.6, time: "5–10 min", emoji: "🍹", badge: "Refreshing", color: "#70a37f" },
  { id: 12, name: "Cold Brew Tonic", description: "Small-batch cold brew, tonic, orange peel and rosemary.", price: 5.5, category: "Drinks", rating: 4.7, time: "5–10 min", emoji: "☕", badge: "Energizing", color: "#8b6f5a" }
];

async function initializeDatabase() {
  if (!DATABASE_URL) throw new Error("DATABASE_URL is missing. Copy .env.example to .env and set your PostgreSQL connection.");
  await pool.query([
    "CREATE TABLE IF NOT EXISTS users (",
    "id BIGSERIAL PRIMARY KEY,",
    "name VARCHAR(80) NOT NULL,",
    "email VARCHAR(255) NOT NULL UNIQUE,",
    "password_hash TEXT NOT NULL,",
    "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
    ");",
    "CREATE TABLE IF NOT EXISTS sessions (",
    "token VARCHAR(128) PRIMARY KEY,",
    "user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,",
    "expires_at TIMESTAMPTZ NOT NULL",
    ");",
    "CREATE INDEX IF NOT EXISTS sessions_expires_idx ON sessions(expires_at);",
    "CREATE TABLE IF NOT EXISTS orders (",
    "id VARCHAR(40) PRIMARY KEY,",
    "user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,",
    "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),",
    "status VARCHAR(30) NOT NULL,",
    "customer_json JSONB NOT NULL,",
    "items_json JSONB NOT NULL,",
    "payment_method VARCHAR(20) NOT NULL,",
    "notes VARCHAR(500),",
    "subtotal NUMERIC(10,2) NOT NULL,",
    "delivery_fee NUMERIC(10,2) NOT NULL,",
    "service_fee NUMERIC(10,2) NOT NULL,",
    "total NUMERIC(10,2) NOT NULL",
    ");",
    "CREATE INDEX IF NOT EXISTS orders_user_idx ON orders(user_id);",
    "CREATE INDEX IF NOT EXISTS orders_created_idx ON orders(created_at DESC);"
  ].join(""));
}

function parseCookies(header = "") {
  return Object.fromEntries(header.split(";").map((part) => part.trim().split("=")).filter((pair) => pair[0]).map(([key, value]) => [key, decodeURIComponent(value || "")]));
}

async function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const derived = await scrypt(password, salt, 64);
  return salt + ":" + Buffer.from(derived).toString("hex");
}

async function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(":");
  const candidate = await hashPassword(password, salt);
  return crypto.timingSafeEqual(Buffer.from(candidate.split(":")[1], "hex"), Buffer.from(hash, "hex"));
}

function publicUser(user) {
  return user ? { id: Number(user.id), name: user.name, email: user.email } : null;
}

async function createSession(userId, res) {
  const token = crypto.randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  await pool.query("INSERT INTO sessions (token, user_id, expires_at) VALUES ($1, $2, $3)", [token, userId, expires]);
  res.setHeader("Set-Cookie", "zoopy_session=" + token + "; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800");
}

app.use(express.json({ limit: "50kb" }));
app.use(async (req, _res, next) => {
  try {
    const token = parseCookies(req.headers.cookie).zoopy_session;
    req.sessionToken = token;
    if (!token) {
      req.user = null;
      return next();
    }
    const result = await pool.query("SELECT users.id, users.name, users.email FROM sessions JOIN users ON users.id = sessions.user_id WHERE sessions.token = $1 AND sessions.expires_at > NOW()", [token]);
    req.user = result.rows[0] || null;
    next();
  } catch (error) {
    next(error);
  }
});
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", async (_req, res) => {
  const result = await pool.query("SELECT NOW() AS database_time");
  res.json({ ok: true, database: "postgresql", databaseTime: result.rows[0].database_time });
});
app.get("/api/menu", (_req, res) => res.json(menu));
app.get("/api/auth/me", (req, res) => res.json({ user: publicUser(req.user) }));

app.post("/api/auth/register", async (req, res) => {
  try {
    const name = String(req.body?.name || "").trim();
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    if (name.length < 2 || name.length > 80) return res.status(400).json({ error: "Enter your full name." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
    if (password.length < 8 || password.length > 128) return res.status(400).json({ error: "Password must be at least 8 characters." });
    const passwordHash = await hashPassword(password);
    const result = await pool.query("INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, name, email", [name, email, passwordHash]);
    const user = result.rows[0];
    await createSession(user.id, res);
    res.status(201).json({ user: publicUser(user) });
  } catch (error) {
    if (error.code === "23505") return res.status(409).json({ error: "An account with this email already exists." });
    console.error(error);
    res.status(500).json({ error: "Unable to create your account right now." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    const result = await pool.query("SELECT * FROM users WHERE LOWER(email) = $1", [email]);
    const user = result.rows[0];
    if (!user || !(await verifyPassword(password, user.password_hash))) return res.status(401).json({ error: "Incorrect email or password." });
    if (req.sessionToken) await pool.query("DELETE FROM sessions WHERE token = $1", [req.sessionToken]);
    await createSession(user.id, res);
    res.json({ user: publicUser(user) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Unable to sign in right now." });
  }
});

app.post("/api/auth/logout", async (req, res) => {
  if (req.sessionToken) await pool.query("DELETE FROM sessions WHERE token = $1", [req.sessionToken]);
  res.setHeader("Set-Cookie", "zoopy_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0");
  res.json({ ok: true });
});

app.post("/api/orders", async (req, res) => {
  try {
    const { customer, items, paymentMethod, notes = "" } = req.body || {};
    const required = ["name", "email", "phone", "address", "city", "postalCode"];
    if (!customer || required.some((field) => !String(customer[field] || "").trim())) return res.status(400).json({ error: "Please complete all delivery details." });
    if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "Your cart is empty." });
    if (!["card", "cash"].includes(paymentMethod)) return res.status(400).json({ error: "Choose a valid payment method." });

    let subtotal = 0;
    const normalizedItems = items.map(({ id, quantity }) => {
      const product = menu.find((entry) => entry.id === Number(id));
      const qty = Number(quantity);
      if (!product || !Number.isInteger(qty) || qty < 1 || qty > 20) throw new Error("One or more cart items are invalid.");
      subtotal += product.price * qty;
      return { id: product.id, name: product.name, price: product.price, quantity: qty };
    });
    const deliveryFee = subtotal >= 35 ? 0 : 3.99;
    const serviceFee = Number((subtotal * 0.05).toFixed(2));
    const total = Number((subtotal + deliveryFee + serviceFee).toFixed(2));
    const now = new Date();
    const cleanCustomer = Object.fromEntries(required.map((field) => [field, String(customer[field]).trim()]));
    const order = {
      id: "ZOOPY-" + now.getFullYear() + "-" + Math.random().toString(36).slice(2, 8).toUpperCase(),
      createdAt: now.toISOString(), status: "confirmed", estimatedMinutes: 35,
      customer: cleanCustomer, items: normalizedItems, paymentMethod,
      notes: String(notes).trim().slice(0, 500),
      totals: { subtotal: Number(subtotal.toFixed(2)), deliveryFee, serviceFee, total }
    };
    await pool.query(
      "INSERT INTO orders (id, user_id, created_at, status, customer_json, items_json, payment_method, notes, subtotal, delivery_fee, service_fee, total) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)",
      [order.id, req.user?.id || null, order.createdAt, order.status, cleanCustomer, normalizedItems, paymentMethod, order.notes, order.totals.subtotal, deliveryFee, serviceFee, total]
    );
    res.status(201).json({ order });
  } catch (error) {
    const validation = error.message.includes("cart items");
    console.error(error);
    res.status(validation ? 400 : 500).json({ error: validation ? error.message : "Unable to place the order right now." });
  }
});

app.use("/api", (_req, res) => res.status(404).json({ error: "API route not found." }));
app.get("*splat", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: "The database is temporarily unavailable." });
});

async function startServer() {
  await initializeDatabase();
  return app.listen(PORT, () => console.log("Zoopy Food Delivery Services is ready at http://localhost:" + PORT));
}

if (require.main === module) {
  startServer().catch((error) => {
    console.error("Startup failed:", error.message);
    process.exitCode = 1;
  });
}

module.exports = { app, pool, initializeDatabase, startServer };
