'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Image from 'next/image';
import { 
  Sparkles, 
  ChevronRight, 
  Star, 
  MapPin, 
  Phone, 
  Calculator, 
  CheckCircle2, 
  ArrowUpRight, 
  ChevronLeft, 
  Send, 
  MessageSquare,
  X,
  Plus,
  Minus,
  Check,
  HelpCircle,
  Menu,
  Clock,
  ArrowRight,
  Database,
  ArrowUp,
  Sliders,
  Award,
  ShieldCheck,
  Zap,
  Users
} from 'lucide-react';

// Design System Colors mapping (Luxe Minimalist Gold & Charcoal Theme)
// primary black: hover bg and text
// accent gold: border or light details

interface Testimonial {
  id: number;
  name: string;
  role: string;
  rating: number;
  text: string;
  details: string;
}

interface PortfolioItem {
  id: number;
  title: string;
  category: string;
  image: string;
  description: string;
  materials: string[];
  area: string;
}

interface Inquiry {
  id: string;
  name: string;
  phone: string;
  email: string;
  service: string;
  packageType: string;
  budgetEst: string;
  status: 'Pending' | 'Scheduled' | 'Designing' | 'Completed';
  date: string;
  specialRequests?: string;
}

const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 1,
    title: 'The Walnut Retreat - Living Area',
    category: 'Living Rooms',
    image: 'https://lh3.googleusercontent.com/aida/AP1WRLvbHvvgYWFKKIZNl8CqbmJK-CtW-MZHBUFNMIR34JlnxprSnGmbisWVRXzYJVWCQHrRZdIOkJTfhU8HdclX14UuIVXGE1hwtD4-S2xKiQ3Va-iq7x5jQmFW1rodaXfg_Hzvor0Rh3nH3y5ADE0G9c2KWwa95PO2iGi0xih3UWLEAQAXd0Vt1WuATGoLR0R6hH540bfhiIPHLXGmq-fcPkHKS9WEj1A_jfxXHrJI6Q5OKQR7XfEJQwNTlCw',
    description: 'Bespoke joinery with custom-milled organic walnut. Merges natural tactile textures with structural minimalist lines to create a breathable social hearth.',
    materials: ['Reclaimed American Walnut', 'Muted Plaster', 'Bronze Trim', 'Integrated COB Lighting'],
    area: '480 Sq.Ft.',
  },
  {
    id: 2,
    title: 'Terracotta Dreams - Master Sanctuary',
    category: 'Bedrooms',
    image: 'https://lh3.googleusercontent.com/aida/AP1WRLuveJcJAnqy2Fxnr9rsff4ixAuVh-vlDET3h3OsXUmY_pq1hPxcLq-qp7HNlBaHcsPyQXpceZfRxbEaD39sM2YytMCq3kbhSRMfEENCSh0Ip7hH3dQ_9KvGSVpD8JFzIvWr384HsgK1SDTRxlqx5iTzLArhSm2i0xHxl0fifOp8rpo54c-Brz0bC3AVD5TEyuAb_gue461B_1THgQOQGvijSyCJ3Ft6Ay5Gh8UpoUZB6d_cZ8xq16CPv0s',
    description: 'A serene resting chamber exploring raw tactile materiality. Layered organic linens combined with hand-glazed ceramics and warm, natural earth tones.',
    materials: ['Earthy Stucco Plaster', 'Belgian Off-white Linen', 'Terracotta Textile Decor', 'Oatmeal Travertine'],
    area: '340 Sq.Ft.',
  },
  {
    id: 3,
    title: 'Minimalist Monolithic Culinary Workspace',
    category: 'Kitchens',
    image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?q=80&w=1200&auto=format&fit=crop',
    description: 'A striking seamless modular kitchen. Clean continuous lines conceal state-of-the-art smart storage compartments, finished with custom gold anodized pulls.',
    materials: ['Suede-finished Calacatta Marble', 'Anti-fingerprint Matte Lacquer', 'Satin Gold Anodized Stainless Steel'],
    area: '220 Sq.Ft.',
  },
  {
    id: 4,
    title: 'Modern Architecture - Facade & Elevation',
    category: 'Exterior Designs',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1200&auto=format&fit=crop',
    description: 'A bold, contemporary residential exterior in Ahmedabad. Striking geometric projections interlock with wooden louvers to direct soft shadow play.',
    materials: ['Exposed Structural Concrete', 'Indian Teak Cladding', 'Thermally Broken Black Aluminum Profile'],
    area: '3,200 Sq.Ft.',
  },
  {
    id: 5,
    title: 'Luxurious Double Height Lounge',
    category: 'Living Rooms',
    image: 'https://lh3.googleusercontent.com/aida/AP1WRLswdhIYv8c6mkMJQgHrE2oVUlZ5tv2duq_gfBjp2hXu9EvMA0xMG6FEqjTxAb40zP62nGu-ZMYn0KOcjytbcrJRvVxqcaaXXn_wPwECtTd83BdNWxytOqukg38oKMTjOJ1r1NojMcR0i5e0xnevc-2pOx4gLK2P4CWATRYVPq02aXsHvDrlrekbbx7I7TsKOsPESnvB97TsvFbvv2izA6MqSM7INWwbvfup4cdoUNo5zuvEAbiuQyxOFOw',
    description: 'A high-concept reception hall designed to reflect spatial majesty. Architectural symmetrical glass profiles optimize Ahmedabad\'s exquisite clear skies.',
    materials: ['Brushed Champagne Gold Panels', 'Polished Crema Marfil Flooring', 'Bouclé Custom Seating'],
    area: '620 Sq.Ft.',
  },
  {
    id: 6,
    title: 'The Co-Working Atelier',
    category: 'Offices',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1200&auto=format&fit=crop',
    description: 'An inspiring corporate workspace boosting creative team synergy. Acoustic oak slats pair elegantly with structural glass enclosures.',
    materials: ['Acoustic Oak Panels', 'Industrial Black Framing', 'Terrazzo Tiles'],
    area: '1,500 Sq.Ft.',
  }
];

const SERVICES = [
  {
    title: 'Interior Design',
    desc: 'Bespoke custom detailing, handcrafted joinery, and tailored layout schemes that maximize spatial utility while exuding quiet luxury.',
    code: 'INT'
  },
  {
    title: 'Exterior Design',
    desc: 'Breathtaking facades, luxury residential elevation, clean modern massing, and context-aware landscape detailing.',
    code: 'EXT'
  },
  {
    title: 'Building Design',
    desc: 'End-to-end architectural structure design, core floor plan engineering, zoning approvals, and spatial orientation.',
    code: 'BLD'
  },
  {
    title: 'Modular Kitchen',
    desc: 'Ultra-premium, German-engineered soft-close cabinetry, seamless continuous countertops, and optimized smart storage layouts.',
    code: 'KIT'
  },
  {
    title: 'Living Room Design',
    desc: 'Grand double-height spaces, symmetric architectural statement walls, cozy ambient hearths, and thoughtfully curated furniture arrangements.',
    code: 'LIV'
  },
  {
    title: 'Bedroom Design',
    desc: 'Sensory sanctuary spaces focusing on acoustical isolation, customized fabric headboards, and warm integrated indirect light scenes.',
    code: 'BED'
  },
  {
    title: 'Office Interiors',
    desc: 'Premium commercial showrooms, dynamic co-working environments, and executive corporate suites that represent brand authority.',
    code: 'OFF'
  },
  {
    title: 'Renovation Services',
    desc: 'Complete high-end structural transformations, electrical overhaul, plumbing refitting, and modern finish rejuvenations.',
    code: 'REN'
  },
];

const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: 'Harshit Patel',
    role: 'Naranpura Resident',
    rating: 5,
    text: 'Nice work and low price.',
    details: 'Afkain team completely transformed our 3 BHK in Ahmedabad. They handled the 3D drawings with extreme precision. Outstanding turnkey coordination, no hidden costs!'
  },
  {
    id: 2,
    name: 'Suhail Shaikh',
    role: 'Business Owner, CG Road',
    rating: 5,
    text: 'He has good skills and good design work.',
    details: 'The modern elevation facade that they designed for our commercial office is fantastic. Excellent understanding of materials like concrete, steel, and custom wood panels.'
  },
  {
    id: 3,
    name: 'Bhavna Shah',
    role: 'Villa Owner, South Bopal',
    rating: 5,
    text: 'Creative space designs and timely execution.',
    details: 'Highly professional designers who actually listen! They completed our modular kitchen in record time and took care of every single hairline gap with gold metallic inserts.'
  },
];

export default function HomePage() {
  // Mobile menu state
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  
  // Navigation active tab
  const [activeSection, setActiveSection] = React.useState('home');

  // Contact form state
  const [formInquiry, setFormInquiry] = React.useState({
    name: '',
    phone: '',
    email: '',
    service: 'Interior Design',
    packageType: '2 BHK Interior Package',
    specialRequests: '',
  });
  const [loadingForm, setLoadingForm] = React.useState(false);
  const [formSuccess, setFormSuccess] = React.useState(false);

  // Leads DB List in local storage
  const [leads, setLeads] = React.useState<Inquiry[]>([]);
  const [leadDetailOpen, setLeadDetailOpen] = React.useState(false);
  const [activeLead, setActiveLead] = React.useState<Inquiry | null>(null);

  // Portfolio interactive filters and lightbox
  const [portfolioFilter, setPortfolioFilter] = React.useState('All');
  const [lightboxIndex, setLightboxIndex] = React.useState<number | null>(null);

  // Testimonial index
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);

  // Interactive standard or custom estimator
  const [estimationLayout, setEstimationLayout] = React.useState<'1BHK' | '2BHK' | '3BHK' | 'Custom'>('2BHK');
  const [materialTier, setMaterialTier] = React.useState<'Premium' | 'Luxury' | 'Elite'>('Luxury');
  const [addonKitchen, setAddonKitchen] = React.useState(true);
  const [addonCeiling, setAddonCeiling] = React.useState(true);
  const [addonWardrobes, setAddonWardrobes] = React.useState(false);
  const [addonWallTreatment, setAddonWallTreatment] = React.useState(false);
  const [customSqFt, setCustomSqFt] = React.useState(1200);

  // AI Chat Drawer states
  const [chatOpen, setChatOpen] = React.useState(false);
  const [chatInput, setChatInput] = React.useState('');
  const [chatMessages, setChatMessages] = React.useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    { role: 'assistant', content: "Welcome to Afkain Interior Studio. I'm Aria, your custom AI space stylist. Let's paint an ideal aesthetic for your home. Are we planning a cozy living room, a modern kitchen, or exploring a full-home design package?" }
  ]);
  const [aiTyping, setAiTyping] = React.useState(false);
  
  // Back to top button
  const [showScrollTop, setShowScrollTop] = React.useState(false);

  // Sync leads from localStorage
  React.useEffect(() => {
    const stored = localStorage.getItem('afkain_leads');
    if (stored) {
      try {
        setLeads(JSON.parse(stored));
      } catch (e) {
        console.error(e);
      }
    } else {
      // Seed initial dummy inquiries for interactive dashboard demonstration!
      const initial: Inquiry[] = [
        {
          id: 'AFK-8902',
          name: 'Arpit Patel',
          phone: '098250 12345',
          email: 'arpit@ahmedabad.com',
          service: 'Interior Design',
          packageType: '3 BHK Interior Package',
          budgetEst: '₹6,40,000',
          status: 'Scheduled',
          date: '2026-06-06',
          specialRequests: 'Prefers walnut textures with warm brass hardware'
        },
        {
          id: 'AFK-4491',
          name: 'Neha Mehta',
          phone: '070430 98551',
          email: 'neha@mehta.org',
          service: 'Modular Kitchen',
          packageType: 'Custom Designer Budget',
          budgetEst: '₹2,10,000',
          status: 'Pending',
          date: '2026-06-07',
          specialRequests: 'Soft close high gloss gray finish kitchen'
        }
      ];
      localStorage.setItem('afkain_leads', JSON.stringify(initial));
      setLeads(initial);
    }

    // Scroll tracker
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);

      // Simple active nav tracker
      const sections = ['home', 'about', 'services', 'packages', 'portfolio', 'reviews', 'contact'];
      for (const sect of sections) {
        const el = document.getElementById(sect);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 160 && rect.bottom >= 160) {
            setActiveSection(sect);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle inquiry submission
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formInquiry.name || !formInquiry.phone) return;

    setLoadingForm(true);

    setTimeout(() => {
      const generatedId = `AFK-${Math.floor(1000 + Math.random() * 9000)}`;
      const newInquiry: Inquiry = {
        id: generatedId,
        name: formInquiry.name,
        phone: formInquiry.phone,
        email: formInquiry.email || 'None',
        service: formInquiry.service,
        packageType: formInquiry.packageType,
        budgetEst: getComputedTotalLabel(),
        status: 'Pending',
        date: new Date().toISOString().split('T')[0],
        specialRequests: formInquiry.specialRequests || undefined,
      };

      const updated = [newInquiry, ...leads];
      setLeads(updated);
      localStorage.setItem('afkain_leads', JSON.stringify(updated));

      setLoadingForm(false);
      setFormSuccess(true);

      // Auto clear success indicator
      setTimeout(() => {
        setFormSuccess(false);
        setFormInquiry({
          name: '',
          phone: '',
          email: '',
          service: 'Interior Design',
          packageType: '2 BHK Interior Package',
          specialRequests: '',
        });
      }, 5000);
    }, 1200);
  };

  // Live Pricing estimation calculation logic
  const calculateEstimateValue = () => {
    let base = 0;
    if (estimationLayout === '1BHK') {
      base = 350000;
    } else if (estimationLayout === '2BHK') {
      base = 480000;
    } else if (estimationLayout === '3BHK') {
      base = 600000;
    } else {
      // Custom SQFT model (₹1,200/sqft base)
      base = customSqFt * 1250;
    }

    // Apply material premium tier coefficient
    let multiplier = 1.0;
    if (materialTier === 'Luxury') multiplier = 1.25;
    if (materialTier === 'Elite') multiplier = 1.55;

    let computed = base * multiplier;

    // Apply toggle addons
    if (addonKitchen && estimationLayout !== 'Custom') computed += 120000;
    if (addonCeiling) computed += 45000;
    if (addonWardrobes) computed += 85000;
    if (addonWallTreatment) computed += 60000;

    return Math.round(computed);
  };

  const getComputedTotalLabel = () => {
    const sum = calculateEstimateValue();
    return `₹${sum.toLocaleString('en-IN')}`;
  };

  const syncEstimateToForm = () => {
    let typeStr = `${estimationLayout} Plan Design`;
    if (estimationLayout !== 'Custom') {
      typeStr = `${estimationLayout} Interior Package (${materialTier} grade)`;
    }
    setFormInquiry(prev => ({
      ...prev,
      packageType: typeStr,
      specialRequests: `Estimated estimate calculated on workspace customizer: ${getComputedTotalLabel()} | Material selection: ${materialTier} grade quality.`,
    }));

    // Auto scroll to contact form with brief highlight
    const contactFormEl = document.getElementById('contact');
    if (contactFormEl) {
      contactFormEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // AI chat API submit handler
  const handleSendChatMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim() || aiTyping) return;

    const userMsg = chatInput.trim();
    const workingHistory = [...chatMessages, { role: 'user' as const, content: userMsg }];
    
    setChatMessages(workingHistory);
    setChatInput('');
    setAiTyping(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: workingHistory,
        }),
      });

      if (!response.ok) {
        throw new Error('Our AI server is taking a coffee breakout. Please hold on.');
      }

      const data = await response.json();
      setChatMessages(prev => [...prev, { role: 'assistant', content: data.content }]);
    } catch (err: any) {
      setChatMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `I hit a temporary layout hiccup: ${err?.message || "Verify your GEMINI_API_KEY inside AI Studio setup."} Let me assist you directly: Afkain Office can be reached at 084880 95593.` 
      }]);
    } finally {
      setAiTyping(false);
    }
  };

  // Quick prompt triggers for luxury clients
  const handleQuickPrompt = (promptText: string) => {
    setChatInput(promptText);
    setTimeout(() => {
      // Let it trigger send
      setChatInput(promptText);
    }, 100);
  };

  // Active leads helper mapping
  const handleInquiryStatusChange = (id: string, newStatus: Inquiry['status']) => {
    const updated = leads.map(l => l.id === id ? { ...l, status: newStatus } : l);
    setLeads(updated);
    localStorage.setItem('afkain_leads', JSON.stringify(updated));
    if (activeLead && activeLead.id === id) {
      setActiveLead({ ...activeLead, status: newStatus });
    }
  };

  const handleInquiryDelete = (id: string) => {
    const updated = leads.filter(l => l.id !== id);
    setLeads(updated);
    localStorage.setItem('afkain_leads', JSON.stringify(updated));
    setLeadDetailOpen(false);
    setActiveLead(null);
  };

  // Portfolio items filter mapping
  const filteredPortfolio = portfolioFilter === 'All' 
    ? PORTFOLIO_ITEMS 
    : PORTFOLIO_ITEMS.filter(item => item.category === portfolioFilter);

  return (
    <div className="relative min-h-screen font-sans antialiased text-charcoal-800 bg-[#fbfbf9]" id="home">
      
      {/* Interactive Admin Lead CRM Button - Floating at High Center Left (Simulating developer back-office tool clearly) */}
      <div className="fixed left-6 top-24 z-40 hidden lg:block">
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setLeadDetailOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-charcoal-900 border border-gold-400 text-gold-400 rounded-full text-xs font-semibold uppercase tracking-wider soft-shadow backdrop-blur-md"
        >
          <Database className="w-3.5 h-3.5 animate-pulse" />
          CRM Leads Log ({leads.length})
        </motion.button>
      </div>

      {/* Floating Action Buttons Area Bottom Right */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-4">
        {/* WhatsApp Button */}
        <motion.a
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          href="https://wa.me/918488095593?text=Hi%20Afkain%20Interior%20Designer%20I'd%20like%20to%20request%20a%20free%20consultation"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center w-14 h-14 bg-[#25D366] text-white rounded-full shadow-lg hover:brightness-110 transition-all cursor-pointer"
        >
          {/* Custom SVG for WhatsApp */}
          <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.455 5.703 1.458h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
          </svg>
        </motion.a>

        {/* Custom AI Chat Button */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setChatOpen(!chatOpen)}
          className={`flex items-center justify-center w-14 h-14 rounded-full shadow-lg cursor-pointer ${chatOpen ? 'bg-charcoal-950 text-gold-400' : 'bg-gold-500 text-charcoal-950'}`}
        >
          {chatOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
        </motion.button>
        
        {/* Back to top arrow */}
        <AnimatePresence>
          {showScrollTop && (
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="flex items-center justify-center w-14 h-14 bg-charcoal-900 border border-charcoal-700 text-neutral-300 rounded-full shadow-md hover:text-white"
            >
              <ArrowUp className="w-5 h-5" />
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {/* Sticky High-End Header */}
      <header className="sticky top-0 left-0 w-full z-45 border-b border-light/10 transition-all duration-300 bg-neutral-50/70 backdrop-blur-xl">
        <div className="flex justify-between items-center px-6 md:px-20 py-5 w-full max-w-[1440px] mx-auto">
          {/* Logo */}
          <a className="flex items-center gap-2.5" href="#home">
            <span className="font-serif text-xl md:text-2xl font-bold tracking-tight text-charcoal-900">
              Afkain <span className="text-gold-500">Interior</span>
            </span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden xl:flex space-x-8 items-center">
            {['home', 'about', 'services', 'packages', 'portfolio', 'reviews', 'contact'].map((item) => (
              <a
                key={item}
                className={`font-sans text-xs uppercase tracking-widest font-semibold transition-all duration-200 hover:text-gold-500 ${activeSection === item ? 'text-gold-500 border-b border-gold-500 pb-1' : 'text-charcoal-400'}`}
                href={`#${item}`}
              >
                {item}
              </a>
            ))}
          </nav>

          {/* ContactCTA */}
          <div className="hidden xl:flex items-center gap-5">
            <a className="text-xs uppercase tracking-wider font-semibold text-charcoal-600 hover:text-gold-500 transition-colors" href="tel:08488095593">
              084880 95593
            </a>
            <a 
              className="px-5 py-2.5 bg-charcoal-950 text-white font-semibold text-xs tracking-wider uppercase rounded-sm hover:bg-gold-500 hover:text-charcoal-950 glow-hover transition-all duration-200" 
              href="#contact"
            >
              Bespoke Consultation
            </a>
          </div>

          {/* Mobile responsive toggle */}
          <button className="xl:hidden text-charcoal-900" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            <Menu className="w-6 h-6" />
          </button>
        </div>

        {/* Mobile Navigation Panel */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="xl:hidden bg-neutral-50 border-b border-charcoal-100 overflow-hidden px-8 py-5"
            >
              <div className="flex flex-col space-y-4">
                {['home', 'about', 'services', 'packages', 'portfolio', 'reviews', 'contact'].map((item) => (
                  <a
                    key={item}
                    className="font-sans text-xs uppercase tracking-widest font-bold py-1 text-charcoal-600 hover:text-gold-500"
                    href={`#${item}`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item}
                  </a>
                ))}
                <div className="pt-2 flex flex-col gap-3">
                  <a className="text-sm font-semibold text-charcoal-800" href="tel:08488095593">
                    Call: 084880 95593
                  </a>
                  <a 
                    className="py-3 text-center bg-charcoal-950 text-white text-xs uppercase tracking-wider font-bold rounded-sm"
                    href="#contact"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Free Consultation
                  </a>
                  <button 
                    onClick={() => { setLeadDetailOpen(true); setMobileMenuOpen(false); }}
                    className="py-2.5 text-center bg-neutral-100 text-charcoal-800 text-xs uppercase tracking-wider font-semibold border rounded-sm"
                  >
                    CRM Logs Workspace
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Container */}
      <main className="overflow-x-hidden">
        
        {/* Luxury Hero Section */}
        <section className="relative min-h-[90vh] md:min-h-screen py-16 xl:py-24 px-6 md:px-20 max-w-[1440px] mx-auto flex flex-col xl:flex-row items-center gap-12" id="hero">
          <div className="w-full xl:w-5/12 z-10 relative">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="glass-panel p-8 md:p-14 soft-shadow xl:-ml-12 relative z-20"
            >
              <div className="inline-flex items-center gap-2 mb-4 px-2.5 py-1 bg-gold-50 text-gold-700 text-[10px] uppercase tracking-widest font-bold rounded-full">
                <Sparkles className="w-3 h-3 text-gold-500 animate-spin" />
                BESPOKE DESIGN SOLUTIONS
              </div>
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-charcoal-900 font-bold tracking-tight leading-tight mb-6">
                Artisanal Spaces,<br />
                <span className="text-gold-500">Personalized</span> Design.
              </h1>
              <p className="font-sans text-sm md:text-base text-charcoal-400 leading-relaxed mb-8 max-w-lg">
                We blend tactile materials, earthy tones, and masterful craftsmanship to create gorgeous residential elevations and premium modular turnkey interiors in Ahmedabad. Experience the warmth of considered luxury.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <a 
                  className="inline-flex items-center justify-center px-7 py-3.5 bg-charcoal-950 text-white font-semibold text-xs uppercase tracking-widest hover:bg-gold-500 hover:text-charcoal-950 transition-all rounded-sm glow-hover shadow-md text-center" 
                  href="#contact"
                >
                  Start Your Project
                </a>
                <a 
                  className="inline-flex items-center justify-center px-7 py-3.5 border border-charcoal-900 text-charcoal-900 font-semibold text-xs uppercase tracking-widest hover:bg-charcoal-100 transition-all rounded-sm text-center" 
                  href="#portfolio"
                >
                  View Gallery
                </a>
              </div>

              {/* Floating review badge */}
              <div className="mt-8 pt-6 border-t border-charcoal-100 flex items-center gap-4">
                <div className="flex text-gold-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4.5 h-4.5 fill-current" />
                  ))}
                </div>
                <div>
                  <span className="text-sm font-bold text-charcoal-900 block">⭐ 5.0 Rating</span>
                  <span className="text-2xs text-charcoal-400 uppercase tracking-widest">98+ Trusted Google Reviews | Ahmedabad</span>
                </div>
              </div>
            </motion.div>
          </div>

          <div className="w-full xl:w-7/12 relative mt-6 xl:mt-0">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.9 }}
              className="relative rounded-lg overflow-hidden soft-shadow"
            >
              <div className="relative h-[480px] md:h-[650px] w-full">
                <Image 
                  alt="Artisanal Interior Living Room" 
                  className="object-cover" 
                  src="https://lh3.googleusercontent.com/aida/AP1WRLswdhIYv8c6mkMJQgHrE2oVUlZ5tv2duq_gfBjp2hXu9EvMA0xMG6FEqjTxAb40zP62nGu-ZMYn0KOcjytbcrJRvVxqcaaXXn_wPwECtTd83BdNWxytOqukg38oKMTjOJ1r1NojMcR0i5e0xnevc-2pOx4gLK2P4CWATRYVPq02aXsHvDrlrekbbx7I7TsKOsPESnvB97TsvFbvv2izA6MqSM7INWwbvfup4cdoUNo5zuvEAbiuQyxOFOw"
                  fill
                  sizes="(max-width: 768px) 100vw, 50vw"
                  priority
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-950/40 via-transparent to-transparent"></div>
              
              {/* Image watermarked tag */}
              <div className="absolute bottom-6 right-6 glass-panel py-3.5 px-6 rounded-sm max-w-sm">
                <span className="text-2xs uppercase tracking-widest font-bold text-charcoal-400 block mb-1">DESIGN PALETTE</span>
                <p className="font-serif text-sm font-semibold text-charcoal-900 leading-snug">
                  Organic Earth & Warm Slate Symmetries
                </p>
              </div>
            </motion.div>
            
            {/* Soft decorative background glow circles */}
            <div className="absolute -bottom-10 -left-10 w-72 h-72 bg-gold-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 -z-10"></div>
            <div className="absolute -top-10 -right-10 w-72 h-72 bg-gold-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 -z-10"></div>
          </div>
        </section>


        {/* About Us Narrative & Animated Statistics */}
        <section className="py-24 bg-charcoal-900 text-white relative" id="about">
          <div className="max-w-[1440px] mx-auto px-6 md:px-20 grid grid-cols-1 xl:grid-cols-12 gap-16 items-center">
            
            <div className="xl:col-span-12 mb-4">
              <div className="flex flex-col items-center text-center">
                <div className="text-gold-500 uppercase tracking-widest text-xs font-bold mb-3">OUR HERITAGE</div>
                <h2 className="font-serif text-3xl md:text-5xl text-white font-semibold">Crafting Luxury Spaces Worth Millions</h2>
                <div className="w-16 h-[2px] bg-gold-500 mt-5"></div>
              </div>
            </div>

            <div className="xl:col-span-6 space-y-6">
              <span className="text-gold-400 font-serif italic text-lg leading-relaxed block">
                &ldquo;We do not merely furnish four walls; we coordinate tactile materials, custom structures, and curated warmth to compose homes with architectural narratives.&rdquo;
              </span>
              <p className="text-neutral-400 text-sm md:text-base leading-relaxed">
                Based in Ahmedabad, Gujarat, **Afkain Interior Designer** is an elite architectural interior and exterior planning practice. For over 5 years, we have brought timeless luxury residences, sleek turnkey modular kitchens, and sophisticated commercial spaces to reality across the state.
              </p>
              <p className="text-neutral-400 text-sm md:text-base leading-relaxed">
                Our hallmark is high-fidelity workmanship combined with budget transparency. We match the elite vision of your dream home while guaranteeing execution on-time and with the highest-grade premium raw materials.
              </p>

              {/* Accents bullet lists */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                {[
                  'Professional Elite Architects',
                  'Rigid Price Transparency', 
                  'Detailed 3D Spatial Virtualization',
                  'Timely Project Turnkey Handover'
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Check className="w-4 h-4 text-gold-500 shrink-0" />
                    <span className="text-xs font-semibold tracking-wider text-neutral-300 uppercase">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="xl:col-span-6 relative">
              {/* Stats Bento Grid */}
              <div className="grid grid-cols-2 gap-4">
                {[
                  { value: '5.0 ★', label: 'CLIENT RATING', desc: 'From 98 verified reviews' },
                  { value: '100+', label: 'COMPLETED PROJECTS', desc: 'Premium custom design tasks' },
                  { value: '5+ Yrs', label: 'STUDIO EXPERIENCE', desc: 'Over Ahmedabad workspace' },
                  { value: '100%', label: 'ON-TIME HANDOVER', desc: 'Premium turnkey promise' }
                ].map((stat, i) => (
                  <motion.div 
                    whileHover={{ scale: 1.03 }}
                    key={i} 
                    className="p-6 bg-charcoal-800 border border-charcoal-700 rounded-sm hover:border-gold-500/50 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <span className="text-3xl lg:text-4xl font-serif font-semibold text-gold-400 block mb-2">{stat.value}</span>
                      <span className="text-2xs font-bold uppercase tracking-widest text-neutral-100 block">{stat.label}</span>
                    </div>
                    <span className="text-3xs text-neutral-500 uppercase tracking-wider mt-4 block">{stat.desc}</span>
                  </motion.div>
                ))}
              </div>
              
              <div className="absolute -bottom-10 -right-10 w-56 h-56 bg-gold-400/5 rounded-full filter blur-2xl"></div>
            </div>

          </div>
        </section>


        {/* Project 1: Storytelling Detail Section (As requested in mockup) */}
        <section className="py-24 max-w-[1440px] mx-auto px-6 md:px-20 bg-neutral-50">
          <div className="text-center mb-16">
            <span className="text-gold-500 text-xs font-bold uppercase tracking-widest block mb-1">CURATED NARRATIVES</span>
            <h2 className="font-serif text-3xl md:text-5xl text-charcoal-900">Storytelling Spaces</h2>
            <p className="text-charcoal-400 text-sm max-w-lg mx-auto mt-3">Every design is a highly personalized collaboration, resulting in spaces with tactile warmth and custom architecture.</p>
          </div>

          {/* Project Narrative 1 */}
          <div className="flex flex-col xl:flex-row items-center gap-12 mb-24 relative">
            <div className="w-full xl:w-1/2 relative h-[350px] md:h-[500px] rounded-lg overflow-hidden soft-shadow">
              <Image 
                alt="Bespoke Kitchen Cabinetry" 
                className="object-cover" 
                src="https://lh3.googleusercontent.com/aida/AP1WRLvbHvvgYWFKKIZNl8CqbmJK-CtW-MZHBUFNMIR34JlnxprSnGmbisWVRXzYJVWCQHrRZdIOkJTfhU8HdclX14UuIVXGE1hwtD4-S2xKiQ3Va-iq7x5jQmFW1rodaXfg_Hzvor0Rh3nH3y5ADE0G9c2KWwa95PO2iGi0xih3UWLEAQAXd0Vt1WuATGoLR0R6hH540bfhiIPHLXGmq-fcPkHKS9WEj1A_jfxXHrJI6Q5OKQR7XfEJQwNTlCw"
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                referrerPolicy="no-referrer"
              />
            </div>
            
            <div className="w-full xl:w-1/2 xl:-ml-16 relative z-10">
              <motion.div 
                whileHover={{ y: -5 }}
                className="glass-panel p-8 md:p-14 rounded-lg soft-shadow"
              >
                <div className="inline-block px-3 py-1 bg-charcoal-100 text-charcoal-800 text-[10px] uppercase tracking-widest font-bold rounded-sm mb-4">
                  Organic Modernism
                </div>
                <h3 className="font-serif text-2xl md:text-3.5xl font-semibold text-charcoal-900 mb-4">The Walnut Retreat</h3>
                <p className="text-charcoal-400 text-sm md:text-base leading-relaxed mb-6">
                  A strict focus on the pristine beauty of natural raw ingredients. We sourced rich reclaimed American walnut wood to Mill custom-engineered panelings, perfectly balancing double-height functionality with warm cozy accents.
                </p>
                <a 
                  className="inline-flex items-center gap-1 text-xs uppercase tracking-widest font-semibold text-gold-600 hover:text-gold-700 transition-colors border-b border-gold-600/30 pb-0.5" 
                  href="#portfolio"
                >
                  Explore the process
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </motion.div>
            </div>
          </div>

          {/* Project Narrative 2 */}
          <div className="flex flex-col xl:flex-row-reverse items-center gap-12 relative">
            <div className="w-full xl:w-1/2 relative h-[350px] md:h-[500px] rounded-lg overflow-hidden soft-shadow">
              <Image 
                alt="Textural Bedroom Design" 
                className="object-cover" 
                src="https://lh3.googleusercontent.com/aida/AP1WRLuveJcJAnqy2Fxnr9rsff4ixAuVh-vlDET3h3OsXUmY_pq1hPxcLq-qp7HNlBaHcsPyQXpceZfRxbEaD39sM2YytMCq3kbhSRMfEENCSh0Ip7hH3dQ_9KvGSVpD8JFzIvWr384HsgK1SDTRxlqx5iTzLArhSm2i0xHxl0fifOp8rpo54c-Brz0bC3AVD5TEyuAb_gue461B_1THgQOQGvijSyCJ3Ft6Ay5Gh8UpoUZB6d_cZ8xq16CPv0s"
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                referrerPolicy="no-referrer"
              />
            </div>
            
            <div className="w-full xl:w-1/2 xl:-mr-16 relative z-10">
              <motion.div 
                whileHover={{ y: -5 }}
                className="glass-panel p-8 md:p-14 rounded-lg soft-shadow"
              >
                <div className="inline-block px-3 py-1 bg-charcoal-100 text-charcoal-800 text-[10px] uppercase tracking-widest font-bold rounded-sm mb-4">
                  Tactile Serenity
                </div>
                <h3 className="font-serif text-2xl md:text-3.5xl font-semibold text-charcoal-900 mb-4">Terracotta Dreams</h3>
                <p className="text-charcoal-400 text-sm md:text-base leading-relaxed mb-6">
                  We approached this sanctuary by layering organic clays over sleek minimal templates. Custom plaster wall backdrops support dynamic custom-cast lamps and terracotta linens, introducing comfortable depth.
                </p>
                <a 
                  className="inline-flex items-center gap-1 text-xs uppercase tracking-widest font-semibold text-gold-600 hover:text-gold-700 transition-colors border-b border-gold-600/30 pb-0.5" 
                  href="#portfolio"
                >
                  Explore the process
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </motion.div>
            </div>
          </div>
        </section>


        {/* Services Section with high contrast bento boxes */}
        <section className="py-24 bg-[#121212] text-white" id="services">
          <div className="max-w-[1440px] mx-auto px-6 md:px-20">
            
            <div className="text-center mb-16">
              <span className="text-gold-400 text-xs font-bold uppercase tracking-widest block mb-1">OUR SPECIALTIES</span>
              <h2 className="font-serif text-3xl md:text-5xl text-white">Comprehensive Architectures</h2>
              <p className="text-neutral-400 text-xs md:text-sm max-w-lg mx-auto mt-4 uppercase tracking-wider">
                Luxury design from concept layout to precise turnkey deployment
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
              {SERVICES.map((serv, index) => (
                <motion.div
                  key={index}
                  whileHover={{ y: -8, borderColor: 'rgba(212, 175, 55, 0.5)' }}
                  className="p-8 bg-[#181818] border border-neutral-800 rounded-sm hover:-translate-y-2 transition-all flex flex-col justify-between h-[280px]"
                >
                  <div>
                    <div className="flex justify-between items-start mb-6">
                      <span className="font-serif text-3xs font-semibold px-2.5 py-1 bg-charcoal-800 border border-neutral-700 text-gold-400 tracking-wider">
                        {serv.code}
                      </span>
                      <Sparkles className="w-4 h-4 text-neutral-600 group-hover:text-gold-400" />
                    </div>
                    <h3 className="text-lg font-serif font-semibold text-white mb-3">{serv.title}</h3>
                    <p className="text-neutral-400 text-xs md:text-sm leading-relaxed line-clamp-3">{serv.desc}</p>
                  </div>
                  
                  <div className="pt-4 border-t border-neutral-900/40">
                    <a className="text-2xs text-gold-500 uppercase tracking-widest font-bold flex items-center gap-1 hover:text-white transition-colors" href="#contact">
                      Request Details <ChevronRight className="w-3 h-3" />
                    </a>
                  </div>
                </motion.div>
              ))}
            </div>

          </div>
        </section>


        {/* Luxury Pricing Packages & Dynamic Cost Estimator Workspace */}
        <section className="py-24 bg-white" id="packages">
          <div className="max-w-[1440px] mx-auto px-6 md:px-20">
            
            <div className="text-center mb-16">
              <span className="text-gold-500 text-xs font-bold uppercase tracking-widest block mb-1">TRANSPARENT VALUE</span>
              <h2 className="font-serif text-3xl md:text-5xl text-charcoal-900">Curated Pricing Packages</h2>
              <p className="text-charcoal-400 text-xs md:text-sm uppercase tracking-wider mt-3">Elite standards calibrated to match your home specifications in India</p>
            </div>

            {/* Default Packages Side by Side */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-20">
              
              {/* 1 BHK */}
              <motion.div 
                whileHover={{ y: -4 }}
                className="p-8 md:p-10 border border-charcoal-100 bg-neutral-50 rounded-sm relative flex flex-col justify-between h-full"
              >
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-[#735c00] block mb-2">Essential Luxury</span>
                  <h3 className="font-serif text-2xl font-bold text-charcoal-900">1 BHK Interior Package</h3>
                  <div className="my-6">
                    <span className="text-3xl font-serif font-semibold text-[#1a1c1c]">₹3,50,000</span>
                    <span className="text-xs text-charcoal-400 block mt-1">Starting Turnkey Base</span>
                  </div>
                  <ul className="space-y-3 pt-6 border-t border-charcoal-100 text-charcoal-600 text-sm">
                    {['Custom Spatial Space Layout', 'Living Room Seating & Entertainment Millwork', 'Master Bedroom Custom Wardrobe & Queen Bed', 'Modular Essential Cabinetry Work', 'Realistic 3D Virtualizations', '5-Year Structural Material Warranty'].map((feat, idx) => (
                      <li key={idx} className="flex gap-2 items-start text-xs md:text-sm">
                        <Check className="w-4 h-4 text-gold-500 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-8">
                  <a 
                    onClick={() => {
                      setEstimationLayout('1BHK');
                      setFormInquiry(p => ({ ...p, packageType: '1 BHK Interior Package', specialRequests: 'Selected standard 1 BHK Package ₹3,50,000.' }));
                    }}
                    className="w-full text-center py-3 border border-charcoal-900 hover:bg-charcoal-900 hover:text-white text-xs uppercase tracking-widest font-bold transition-all inline-block rounded-sm"
                    href="#contact"
                  >
                    Select Essential
                  </a>
                </div>
              </motion.div>

              {/* 2 BHK */}
              <motion.div 
                whileHover={{ y: -4 }}
                className="p-8 md:p-10 border-2 border-gold-400 bg-white rounded-lg relative flex flex-col justify-between h-full shadow-lg"
              >
                <div className="absolute top-0 right-10 -translate-y-1/2 bg-gold-400 text-charcoal-950 px-4 py-1 text-2xs uppercase tracking-widest font-bold rounded-full">
                  MOST POPULAR Choice
                </div>
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-gold-600 block mb-2">Exquisite Craftsmanship</span>
                  <h3 className="font-serif text-2xl font-bold text-charcoal-900">2 BHK Interior Package</h3>
                  <div className="my-6">
                    <span className="text-4xl font-serif font-semibold text-charcoal-990">₹4,80,000</span>
                    <span className="text-xs text-charcoal-400 block mt-1">Sought-after bespoke package</span>
                  </div>
                  <ul className="space-y-3 pt-6 border-t border-neutral-100 text-charcoal-600 text-sm">
                    {['Bespoke Space Architecture Mapping', 'Luxury Sofa Seating + Decorative Fluted Panel', 'Master Bed with Padded Tufted Headboard', 'Kid Guest Room Custom Furniture Layouts', 'Full Premium Modular Hardware Wardrobes', 'Premium Lighting Sconces Integration'].map((feat, idx) => (
                      <li key={idx} className="flex gap-2 items-start text-xs md:text-sm">
                        <Check className="w-5 h-5 text-gold-500 shrink-0 mt-0.5" />
                        <span className="font-medium text-charcoal-800">{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-8">
                  <a 
                    onClick={() => {
                      setEstimationLayout('2BHK');
                      setFormInquiry(p => ({ ...p, packageType: '2 BHK Interior Package', specialRequests: 'Selected standard 2 BHK Package ₹4,80,000.' }));
                    }}
                    className="w-full text-center py-3.5 bg-charcoal-950 text-white hover:bg-gold-500 hover:text-charcoal-950 text-xs uppercase tracking-widest font-bold transition-all inline-block rounded-sm glow-hover"
                    href="#contact"
                  >
                    Select Exquisite
                  </a>
                </div>
              </motion.div>

              {/* 3 BHK */}
              <motion.div 
                whileHover={{ y: -4 }}
                className="p-8 md:p-10 border border-charcoal-100 bg-neutral-50 rounded-sm relative flex flex-col justify-between h-full"
              >
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-[#735c00] block mb-2">Grandeur Elite</span>
                  <h3 className="font-serif text-2xl font-bold text-charcoal-900">3 BHK Interior Package</h3>
                  <div className="my-6">
                    <span className="text-3xl font-serif font-semibold text-[#1a1c1c]">₹6,00,000</span>
                    <span className="text-xs text-charcoal-400 block mt-1">Complete luxury villa base</span>
                  </div>
                  <ul className="space-y-3 pt-6 border-t border-charcoal-100 text-charcoal-600 text-sm">
                    {['Generous Multi-layered Layout Layouts', 'Double Bedroom bespoke furniture pieces', 'Premium Laminated Modular Soft-close Kitchens', 'Symmetric TV Loungers & Suspended Ceilings', 'Exotic Stone Accent Walls Installation', 'Absolute Turnkey Site Supervision'].map((feat, idx) => (
                      <li key={idx} className="flex gap-2 items-start text-xs md:text-sm">
                        <Check className="w-4 h-4 text-gold-500 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-8">
                  <a 
                    onClick={() => {
                      setEstimationLayout('3BHK');
                      setFormInquiry(p => ({ ...p, packageType: '3 BHK Interior Package', specialRequests: 'Selected standard 3 BHK Package ₹6,00,000.' }));
                    }}
                    className="w-full text-center py-3 border border-charcoal-900 hover:bg-charcoal-900 hover:text-white text-xs uppercase tracking-widest font-bold transition-all inline-block rounded-sm"
                    href="#contact"
                  >
                    Select Grandeur
                  </a>
                </div>
              </motion.div>

            </div>

            {/* DYNAMIC COST ESTIMATOR INTERACTIVE PANEL */}
            <motion.div 
              id="calculator"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="p-6 md:p-12 bg-neutral-900 text-white rounded-lg soft-shadow overflow-hidden relative"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-gold-400/5 rounded-full filter blur-3xl"></div>
              
              <div className="relative z-10 grid grid-cols-1 xl:grid-cols-12 gap-10">
                <div className="xl:col-span-12">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-neutral-800 border border-neutral-700 text-gold-400 text-3xs font-semibold tracking-wider uppercase rounded-full mb-3">
                    <Calculator className="w-3 h-3 animate-bounce" />
                    Interactive Estimates
                  </div>
                  <h3 className="font-serif text-2xl md:text-3.5xl font-semibold mb-2">Bespoke Design Budget Customizer</h3>
                  <p className="text-neutral-400 text-xs md:text-sm leading-relaxed max-w-2xl">
                    Slightly personalize raw materials, layout scaling, and structural upgrades dynamically to instantly view your calculated interior design valuation estimate.
                  </p>
                </div>

                {/* Left controls panel */}
                <div className="xl:col-span-7 space-y-6">
                  {/* Select size */}
                  <div>
                    <label className="text-2xs font-bold uppercase tracking-wider text-neutral-400 block mb-3">
                      1. Spatial Layout Specifications
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {(['1BHK', '2BHK', '3BHK', 'Custom'] as const).map((opt) => (
                        <button
                          key={opt}
                          onClick={() => setEstimationLayout(opt)}
                          className={`py-3 text-xs uppercase font-bold tracking-wider border rounded-sm transition-all cursor-pointer ${estimationLayout === opt ? 'bg-gold-500 border-gold-500 text-charcoal-950 font-black' : 'bg-neutral-850 border-neutral-700 text-white'}`}
                        >
                          {opt === 'Custom' ? 'Custom Sq.Ft.' : opt}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* If custom is chosen, slider */}
                  <AnimatePresence>
                    {estimationLayout === 'Custom' && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="p-4 bg-neutral-850 border border-neutral-800 rounded-sm"
                      >
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-xs text-neutral-300">Custom Built-Up Area:</span>
                          <span className="text-sm font-bold text-gold-400">{customSqFt} Sq. Ft.</span>
                        </div>
                        <input
                          type="range"
                          min="500"
                          max="5000"
                          step="50"
                          value={customSqFt}
                          onChange={(e) => setCustomSqFt(Number(e.target.value))}
                          className="w-full accent-gold-500 bg-neutral-800 rounded-md cursor-pointer h-1.5"
                        />
                        <span className="text-3xs text-neutral-500 block mt-2">Ahmedabad Luxury Area Calibration @ ₹1,250 per Sq. Ft.</span>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Select Quality Tier */}
                  <div>
                    <label className="text-2xs font-bold uppercase tracking-wider text-neutral-400 block mb-3">
                      2. Material Grade & Finishes
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {[
                        { tier: 'Premium' as const, label: 'High Grade Standard', desc: 'Laminated finishes, robust marine ply, reliable brand hardware.' },
                        { tier: 'Luxury' as const, label: 'Exquisite Chic Veneer', desc: 'Duco paints, premium acrylic kitchens, custom champagne metal borders.' },
                        { tier: 'Elite' as const, label: 'Ultra Avant-Garde', desc: 'Imported marbles, structural wooden louvers, high-end German soft-close fixtures.' },
                      ].map((item) => (
                        <button
                          key={item.tier}
                          onClick={() => setMaterialTier(item.tier)}
                          className={`p-4 text-left border rounded-sm transition-all focus:outline-none flex flex-col justify-between h-30 cursor-pointer ${materialTier === item.tier ? 'bg-neutral-800 border-gold-400' : 'bg-neutral-850 border-neutral-800 hover:border-neutral-700'}`}
                        >
                          <div className="flex items-center gap-1.5 mb-1">
                            <span className={`w-2.5 h-2.5 rounded-full ${materialTier === item.tier ? 'bg-gold-500' : 'bg-neutral-600'}`}></span>
                            <span className="text-xs uppercase tracking-wider font-extrabold">{item.tier}</span>
                          </div>
                          <span className="text-3xs text-neutral-400 leading-relaxed block">{item.desc}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Addon upgrades toggles */}
                  <div>
                    <label className="text-2xs font-bold uppercase tracking-wider text-neutral-400 block mb-3">
                      3. High-Fidelity Addon Upgrades
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {estimationLayout !== 'Custom' && (
                        <label className="flex items-center justify-between p-3.5 bg-neutral-850 border border-neutral-800 rounded-sm cursor-pointer hover:border-neutral-700">
                          <div className="flex flex-col">
                            <span className="text-xs font-semibold text-neutral-100 uppercase">German Modular Kitchen</span>
                            <span className="text-3xs text-neutral-400 font-medium">+₹1,20,000 Upgraded Cabinetry</span>
                          </div>
                          <input 
                            type="checkbox" 
                            checked={addonKitchen}
                            onChange={(e) => setAddonKitchen(e.target.checked)}
                            className="w-5 h-5 accent-gold-500 rounded cursor-pointer" 
                          />
                        </label>
                      )}

                      <label className="flex items-center justify-between p-3.5 bg-neutral-850 border border-neutral-800 rounded-sm cursor-pointer hover:border-neutral-700">
                        <div className="flex flex-col">
                          <span className="text-xs font-semibold text-neutral-100 uppercase">Cove Ceiling & COB Lights</span>
                          <span className="text-3xs text-neutral-400 font-medium">+₹45,000 Warm Ambient Layouts</span>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={addonCeiling}
                          onChange={(e) => setAddonCeiling(e.target.checked)}
                          className="w-5 h-5 accent-gold-500 rounded cursor-pointer" 
                        />
                      </label>

                      <label className="flex items-center justify-between p-3.5 bg-neutral-850 border border-neutral-800 rounded-sm cursor-pointer hover:border-neutral-700">
                        <div className="flex flex-col">
                          <span className="text-xs font-semibold text-neutral-100 uppercase">Extra Bedroom Wardrobe</span>
                          <span className="text-3xs text-neutral-400 font-medium">+₹85,000 Luxury Laminated Panel</span>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={addonWardrobes}
                          onChange={(e) => setAddonWardrobes(e.target.checked)}
                          className="w-5 h-5 accent-gold-500 rounded cursor-pointer" 
                        />
                      </label>

                      <label className="flex items-center justify-between p-3.5 bg-neutral-850 border border-neutral-800 rounded-sm cursor-pointer hover:border-neutral-700">
                        <div className="flex flex-col">
                          <span className="text-xs font-semibold text-neutral-100 uppercase">Luxury Wall Treatments</span>
                          <span className="text-3xs text-neutral-400 font-medium">+₹60,000 Custom Charcoal Panel / Plaster</span>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={addonWallTreatment}
                          onChange={(e) => setAddonWallTreatment(e.target.checked)}
                          className="w-5 h-5 accent-gold-500 rounded cursor-pointer" 
                        />
                      </label>
                    </div>
                  </div>

                </div>

                {/* Right Summary result card */}
                <div className="xl:col-span-5 bg-neutral-850 p-6 md:p-8 border border-neutral-800 rounded-sm flex flex-col justify-between h-full relative">
                  <div>
                    <h4 className="text-xs uppercase font-extrabold tracking-widest text-[#fed65b] mb-4">
                      Est. DESIGN INVESTMENT SUMMARY
                    </h4>
                    
                    <div className="space-y-4 text-xs md:text-sm text-neutral-300">
                      <div className="flex justify-between pb-3 border-b border-neutral-800">
                        <span>Spatial Blueprint:</span>
                        <span className="font-semibold text-white uppercase">{estimationLayout} Area Setup</span>
                      </div>
                      
                      <div className="flex justify-between pb-3 border-b border-neutral-800">
                        <span>Material Spec Grade:</span>
                        <span className="font-semibold text-white uppercase">{materialTier} Materials</span>
                      </div>

                      <div className="flex justify-between pb-3 border-b border-neutral-800">
                        <span>Addons Configured:</span>
                        <span className="font-semibold text-white">
                          {[
                            addonKitchen && estimationLayout !== 'Custom' ? 'German Kitchen' : null,
                            addonCeiling ? 'Cove Ceiling' : null,
                            addonWardrobes ? 'Addl Wardrobe' : null,
                            addonWallTreatment ? 'Wall Stucco' : null
                          ].filter(Boolean).length} Upgrade(s)
                        </span>
                      </div>
                      
                      <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-sm">
                        <div className="flex items-center gap-2 mb-1.5">
                          <CheckCircle2 className="w-4 h-4 text-gold-400 shrink-0" />
                          <span className="text-2xs font-bold uppercase tracking-wide text-neutral-300">What is included:</span>
                        </div>
                        <p className="text-3xs text-neutral-400 leading-normal">
                          Floor Plan Layout, Detailed 3D High-Res Pictures, Comprehensive Procurement of Select Accessories, On-Site Supervising, Complete Turnkey Setup.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="pt-8 mt-8 border-t border-neutral-800/80">
                    <div className="flex items-baseline justify-between mb-6">
                      <span className="text-neutral-400 uppercase tracking-widest text-[10px] font-bold">Estimated Quote:</span>
                      <span className="text-3xl md:text-4xl font-serif font-semibold text-gold-400">
                        {getComputedTotalLabel()}
                      </span>
                    </div>

                    <p className="text-3xs text-neutral-500 mb-4 leading-normal">
                      *Estimated calculation calibrated for Ahmedabad, Gujarat. Subject to design depth and material changes.
                    </p>

                    <button 
                      onClick={syncEstimateToForm}
                      className="w-full py-4 bg-gold-500 text-charcoal-950 font-extrabold text-xs uppercase tracking-widest hover:bg-white transition-all cursor-pointer rounded-sm flex items-center justify-center gap-2"
                    >
                      Process Estimate to Form
                      <ArrowRight className="w-4 h-4 text-charcoal-950" />
                    </button>
                  </div>
                </div>

              </div>
            </motion.div>

          </div>
        </section>


        {/* Portfolio Masonry Gallery */}
        <section className="py-24 bg-neutral-100" id="portfolio">
          <div className="max-w-[1440px] mx-auto px-6 md:px-20">
            
            <div className="flex flex-col md:flex-row md:justify-between md:items-end mb-16 gap-5">
              <div>
                <span className="text-gold-500 text-xs font-bold uppercase tracking-widest block mb-1">CRAFT MANIFESTO</span>
                <h2 className="font-serif text-3xl md:text-5xl text-charcoal-900">Bespoke Portfolio</h2>
              </div>
              
              {/* Category buttons */}
              <div className="flex flex-wrap gap-2.5">
                {['All', 'Living Rooms', 'Bedrooms', 'Kitchens', 'Offices', 'Exterior Designs'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setPortfolioFilter(cat)}
                    className={`px-4 py-2 text-2xs uppercase tracking-widest font-extrabold rounded-full border transition-all cursor-pointer ${portfolioFilter === cat ? 'bg-charcoal-950 border-charcoal-950 text-gold-400' : 'bg-white border-neutral-200 text-charcoal-500 hover:border-charcoal-300'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Masonry-style Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              <AnimatePresence mode="popLayout">
                {filteredPortfolio.map((item, index) => (
                  <motion.div
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.4 }}
                    key={item.id}
                    onClick={() => setLightboxIndex(index)}
                    className="group relative h-[380px] bg-neutral-900 overflow-hidden cursor-pointer rounded-sm soft-shadow"
                  >
                    <Image 
                      alt={item.title} 
                      className="object-cover group-hover:scale-105 duration-700 transition" 
                      src={item.image}
                      fill
                      sizes="(max-width: 768px) 100vw, 33vw"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Shadow overlay gradient */}
                    <div className="absolute inset-0 bg-gradient-to-t from-charcoal-950/80 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
                    
                    {/* Material indicators */}
                    <div className="absolute top-4 left-4 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <span className="px-2 py-0.5 bg-black/70 border border-gold-500/30 text-gold-400 text-3xs font-extrabold uppercase rounded-full">
                        {item.area}
                      </span>
                    </div>

                    {/* Bottom visual tag info */}
                    <div className="absolute bottom-0 left-0 w-full p-6 text-white translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                      <span className="text-gold-400 text-3xs font-extrabold uppercase tracking-widest block mb-1">
                        {item.category}
                      </span>
                      <h4 className="font-serif text-lg md:text-xl font-bold leading-tight flex items-center gap-1">
                        {item.title}
                        <ArrowUpRight className="w-4 h-4 text-gold-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </h4>
                      <p className="text-3xs text-neutral-300 uppercase font-medium mt-1 shrink opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
                        {item.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

          </div>
        </section>


        {/* Lightbox Viewing Modal */}
        <AnimatePresence>
          {lightboxIndex !== null && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-6"
            >
              <button 
                onClick={() => setLightboxIndex(null)}
                className="absolute top-6 right-6 text-neutral-400 hover:text-white"
              >
                <X className="w-8 h-8" />
              </button>

              <div className="max-w-5xl w-full grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                
                {/* Left/Right image switcher */}
                <div className="md:col-span-8 relative h-[300px] sm:h-[450px] md:h-[550px] rounded-lg overflow-hidden border border-neutral-800">
                  <Image 
                    alt={filteredPortfolio[lightboxIndex].title} 
                    className="object-cover" 
                    src={filteredPortfolio[lightboxIndex].image}
                    fill
                    sizes="100vw, (max-width: 768px)"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Buttons */}
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setLightboxIndex((prev) => (prev! === 0 ? filteredPortfolio.length - 1 : prev! - 1));
                    }}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-3 bg-black/50 border border-neutral-700 text-white rounded-full hover:bg-gold-500 hover:text-charcoal-950 transition-colors"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setLightboxIndex((prev) => (prev! === filteredPortfolio.length - 1 ? 0 : prev! + 1));
                    }}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-black/50 border border-neutral-700 text-white rounded-full hover:bg-gold-500 hover:text-charcoal-950 transition-colors"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>
                </div>

                {/* Lightbox Info Panel */}
                <div className="md:col-span-4 text-white space-y-5">
                  <span className="text-gold-400 text-3xs font-extrabold uppercase tracking-widest block">
                    {filteredPortfolio[lightboxIndex].category} | {filteredPortfolio[lightboxIndex].area}
                  </span>
                  <h3 className="font-serif text-2xl font-bold">{filteredPortfolio[lightboxIndex].title}</h3>
                  <div className="w-10 h-[1.5px] bg-gold-400"></div>
                  
                  <p className="text-neutral-400 text-xs md:text-sm leading-relaxed">
                    {filteredPortfolio[lightboxIndex].description}
                  </p>

                  <div className="space-y-2.5">
                    <span className="text-3xs uppercase font-extrabold tracking-widest text-[#ffe088] block">
                      MATERIALS REGISTER:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {filteredPortfolio[lightboxIndex].materials.map((mat, i) => (
                        <span key={i} className="px-2.5 py-1 bg-neutral-900 border border-neutral-800 text-neutral-300 text-3xs uppercase tracking-wider rounded-sm">
                          {mat}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-6 border-t border-neutral-800">
                    <a 
                      onClick={() => {
                        setFormInquiry(p => ({
                          ...p,
                          service: filteredPortfolio[lightboxIndex!].category.replace('s', ''),
                          specialRequests: `Spotted "${filteredPortfolio[lightboxIndex!].title}" in portfolio gallery and fell in love with it.`
                        }));
                        setLightboxIndex(null);
                      }}
                      className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-bold text-gold-400 hover:text-white transition-colors" 
                      href="#contact"
                    >
                      Inquire About This Look
                      <ArrowUpRight className="w-4 h-4" />
                    </a>
                  </div>

                </div>

              </div>
            </motion.div>
          )}
        </AnimatePresence>


        {/* Why Choose Us Section in Bento Grid representation */}
        <section className="py-24 bg-white">
          <div className="max-w-[1440px] mx-auto px-6 md:px-20">
            
            <div className="text-center mb-16">
              <span className="text-gold-500 text-xs font-bold uppercase tracking-widest block mb-1">STUDIO INTEGRITY</span>
              <h2 className="font-serif text-3xl md:text-5xl text-charcoal-900">Why Luxury Chooses Us</h2>
              <p className="text-charcoal-400 text-xs md:text-sm uppercase tracking-wider mt-3">We balance high-end artistry with engineering discipline</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              
              <div className="p-8 border border-neutral-100 bg-neutral-50 rounded-sm hover:shadow-md transition-all">
                <Award className="w-8 h-8 text-gold-500 mb-6" />
                <h3 className="text-lg font-serif font-semibold text-charcoal-900 mb-2">Award-Winning Concepts</h3>
                <p className="text-charcoal-400 text-xs md:text-sm leading-relaxed">
                  Our designs emerge from robust research in geometries, functional spatial patterns, and custom-cut silhouettes.
                </p>
              </div>

              <div className="p-8 border border-neutral-100 bg-neutral-50 rounded-sm hover:shadow-md transition-all">
                <ShieldCheck className="w-8 h-8 text-gold-500 mb-6" />
                <h3 className="text-lg font-serif font-semibold text-charcoal-900 mb-2">Rigorous Quality Materials</h3>
                <p className="text-charcoal-400 text-xs md:text-sm leading-relaxed">
                  We use boil-proof marine ply, high-density wood fibers, premium hardware and elite laminates designed to resist decay.
                </p>
              </div>

              <div className="p-8 border border-neutral-100 bg-neutral-50 rounded-sm hover:shadow-md transition-all">
                <Clock className="w-8 h-8 text-[#ffe088] bg-[#735c00] rounded-sm p-1.5 mb-6" />
                <h3 className="text-lg font-serif font-semibold text-charcoal-900 mb-2">Punctual Handover Guarantee</h3>
                <p className="text-charcoal-400 text-xs md:text-sm leading-relaxed">
                  Every site follows strict project timelines. We track every design stage, assuring that your keys are handed over on-time.
                </p>
              </div>

              <div className="p-8 border border-neutral-100 bg-neutral-50 rounded-sm hover:shadow-md transition-all">
                <Users className="w-8 h-8 text-gold-500 mb-6" />
                <h3 className="text-lg font-serif font-semibold text-charcoal-900 mb-2">Highly Skilled Craftsmen</h3>
                <p className="text-charcoal-400 text-xs md:text-sm leading-relaxed">
                  Our professional subcontractors, custom artisans, and technical engineers demonstrate exceptional care.
                </p>
              </div>

              <div className="p-8 border border-neutral-100 bg-neutral-50 rounded-sm hover:shadow-md transition-all">
                <Sliders className="w-8 h-8 text-[#ffe088] bg-[#735c00] rounded-sm p-1.5 mb-6" />
                <h3 className="text-lg font-serif font-semibold text-charcoal-900 mb-2">Detailed 3D Virtualization</h3>
                <p className="text-charcoal-400 text-xs md:text-sm leading-relaxed">
                  Never buy a design blindly. We generate extremely detailed realistic 3D renderings to verify color, spacing, and texture scales first.
                </p>
              </div>

              <div className="p-8 border border-neutral-100 bg-neutral-50 rounded-sm hover:shadow-md transition-all">
                <Zap className="w-8 h-8 text-gold-500 mb-6" />
                <h3 className="text-lg font-serif font-semibold text-charcoal-900 mb-2">Absolute Turnkey Solution</h3>
                <p className="text-charcoal-400 text-xs md:text-sm leading-relaxed">
                  From structural layouts and approvals, down to procurement, decorative lights, and micro-polishing: we coordinate everything.
                </p>
              </div>

            </div>

          </div>
        </section>


        {/* Testimonials Slider */}
        <section className="py-24 bg-neutral-900 text-white overflow-hidden relative" id="reviews">
          <div className="absolute top-0 left-0 w-full h-full bg-[#121212]/50 -z-10"></div>
          <div className="max-w-[1440px] mx-auto px-6 md:px-20">
            
            <div className="text-center mb-16">
              <span className="text-gold-400 text-xs font-bold uppercase tracking-widest block mb-1">CLIENT VOICE</span>
              <h2 className="font-serif text-3xl md:text-5xl">98+ Delighted Homeowners</h2>
              <div className="w-10 h-[2px] bg-gold-400 mx-auto mt-4"></div>
            </div>

            <div className="max-w-4xl mx-auto bg-neutral-850 border border-neutral-800 p-8 md:p-14 rounded-sm relative">
              <Sparkles className="absolute top-6 right-6 w-8 h-8 text-neutral-800" />
              
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTestimonial}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex text-gold-400 mb-6">
                    {[...Array(TESTIMONIALS[activeTestimonial].rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>

                  <blockquote className="font-serif text-xl sm:text-2xl font-semibold text-white mb-6 leading-relaxed">
                    &ldquo;{TESTIMONIALS[activeTestimonial].text}&rdquo;
                  </blockquote>
                  
                  <p className="text-neutral-400 text-sm md:text-base leading-relaxed mb-6">
                    {TESTIMONIALS[activeTestimonial].details}
                  </p>

                  <div className="flex justify-between items-center pt-6 border-t border-neutral-800">
                    <div>
                      <span className="font-bold text-white uppercase tracking-wider block">
                        {TESTIMONIALS[activeTestimonial].name}
                      </span>
                      <span className="text-3xs text-gold-400 uppercase tracking-widest">
                        {TESTIMONIALS[activeTestimonial].role}
                      </span>
                    </div>
                    
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setActiveTestimonial((p) => p === 0 ? TESTIMONIALS.length - 1 : p - 1)}
                        className="p-2 border border-neutral-700 text-neutral-400 hover:text-white hover:border-white rounded-full transition-colors cursor-pointer"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => setActiveTestimonial((p) => p === TESTIMONIALS.length - 1 ? 0 : p + 1)}
                        className="p-2 border border-neutral-700 text-neutral-400 hover:text-white hover:border-white rounded-full transition-colors cursor-pointer"
                      >
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

            </div>

          </div>
        </section>


        {/* The 4-Step Interactive Process Timeline */}
        <section className="py-24 bg-[#fcfcfb]" id="process">
          <div className="max-w-[1440px] mx-auto px-6 md:px-20">
            
            <div className="text-center mb-20">
              <span className="text-gold-500 text-xs font-bold uppercase tracking-widest block mb-1">THE EXECUTION</span>
              <h2 className="font-serif text-3xl md:text-5xl text-charcoal-900">4 Steps to Your Masterpiece</h2>
              <p className="text-charcoal-400 text-xs md:text-sm uppercase tracking-wider mt-3">From raw blueprint coordinate down to pristine finished handover</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 relative">
              {[
                { step: '01', title: 'Consultation', desc: 'We meet live in Ahmedabad or via virtual lounge to map your spatial goals, style vibe, and package configurations.' },
                { step: '02', title: 'Design Planning', desc: 'Our architect team drafts extreme-fidelity layout layouts, realistic 3D render designs, and samples real wood veneers.' },
                { step: '03', title: 'Project Execution', desc: 'Craftsmen lock in site materials coordination. We implement wiring, cabinetry framing, stone layers, and custom accents.' },
                { step: '04', title: 'Final Handover', desc: 'We execute strict micro-polishing, setup visual elements, perform a walkthrough, and deliver your completed masterpiece.' }
              ].map((step, i) => (
                <div key={i} className="relative p-6 bg-white border border-neutral-100 rounded-sm hover:shadow-md transition-all">
                  <span className="text-gold-100 font-serif font-extrabold text-5xl md:text-6xl absolute top-4 right-4 z-0">
                    {step.step}
                  </span>
                  
                  <div className="relative z-10 space-y-4 pt-10">
                    <h3 className="font-serif text-xl font-bold text-charcoal-900">{step.title}</h3>
                    <p className="text-charcoal-400 text-xs md:text-sm leading-relaxed">{step.desc}</p>
                  </div>
                  
                  {i < 3 && (
                    <div className="hidden lg:block absolute top-[50%] -right-4 translate-x-1/2 z-20">
                      <ChevronRight className="w-6 h-6 text-neutral-300" />
                    </div>
                  )}
                </div>
              ))}
            </div>

          </div>
        </section>


        {/* Contact Us Form, WhatsApp, & Custom Vector Maps Integration */}
        <section className="py-24 bg-neutral-900 text-white" id="contact">
          <div className="max-w-[1440px] mx-auto px-6 md:px-20 grid grid-cols-1 xl:grid-cols-12 gap-12">
            
            <div className="xl:col-span-5 space-y-8">
              <div className="space-y-4">
                <span className="text-gold-400 text-xs font-bold uppercase tracking-widest block">GET IN TOUCH</span>
                <h2 className="font-serif text-3xl md:text-5xl text-white">Start Your Design Journey</h2>
                <p className="text-neutral-400 text-xs md:text-sm leading-relaxed">
                  Request a complimentary, complete workspace consultation session. Our elite designer will guide you on layouts and cost scaling.
                </p>
              </div>

              <div className="space-y-4 pt-4 border-t border-neutral-800">
                <div className="flex gap-4">
                  <Phone className="w-5 h-5 text-gold-400 shrink-0" />
                  <div>
                    <span className="text-3xs uppercase text-neutral-400 font-extrabold block">Call or Whatsapp:</span>
                    <a className="text-sm font-bold text-white hover:text-gold-400 transition-colors" href="tel:08488095593">
                      084880 95593
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <MapPin className="w-5 h-5 text-gold-400 shrink-0" />
                  <div>
                    <span className="text-3xs uppercase text-neutral-400 font-extrabold block">Studio Office Location:</span>
                    <p className="text-xs text-white leading-relaxed">
                      Gomtipur, Ahmedabad, Gujarat 380021
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <Clock className="w-5 h-5 text-gold-400 shrink-0" />
                  <div>
                    <span className="text-3xs uppercase text-neutral-400 font-extrabold block">Working Hours:</span>
                    <p className="text-xs text-white leading-relaxed">
                      Mon - Sat: 10:00 AM - 08:00 PM
                    </p>
                  </div>
                </div>
              </div>

              {/* Vector Custom Luxury Map Visual Showcase */}
              <div className="rounded-sm overflow-hidden h-[180px] bg-neutral-850 p-6 border border-neutral-800 relative flex flex-col justify-between">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gold-400/10 rounded-full filter blur-xl"></div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-gold-400 animate-ping"></span>
                    <span className="text-xs font-bold uppercase tracking-wide text-neutral-100">GOMTIPUR STUDY DISTRICT</span>
                  </div>
                  <p className="text-3xs text-neutral-400 leading-normal mb-3">
                    Ahmedabad, Gujarat 380021. Conveniently located to supervise project execution teams across double-height estates in Naroda, Nikol, South Bopal, and C.G Road.
                  </p>
                </div>
                <a 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-3xs font-extrabold text-gold-400 uppercase tracking-widest hover:text-white transition-colors flex items-center gap-1.5" 
                  href="https://maps.google.com/?q=Gomtipur,+Ahmedabad,+Gujarat+380021"
                >
                  Locate on Google Maps
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>

            </div>

            {/* Inquiries Lead Capture Form */}
            <div className="xl:col-span-7 bg-[#1a1c1c] border border-neutral-800 p-8 md:p-12 rounded-lg relative">
              <h3 className="font-serif text-2xl font-bold mb-6 text-white text-left"> complimentary consultation</h3>
              
              <form onSubmit={handleFormSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-3xs uppercase text-neutral-400 font-bold block">Your Name *</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g., Bhavik Shah"
                      value={formInquiry.name}
                      onChange={(e) => setFormInquiry(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full bg-[#202020] border-b border-neutral-700 focus:border-gold-400 text-white py-3 px-4 text-sm outline-none transition-all focus:ring-1 focus:ring-gold-500/10"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-3xs uppercase text-neutral-400 font-bold block">Phone Number *</label>
                    <input 
                      type="tel" 
                      required
                      placeholder="e.g., +91 98980 xxxxx"
                      value={formInquiry.phone}
                      onChange={(e) => setFormInquiry(prev => ({ ...prev, phone: e.target.value }))}
                      className="w-full bg-[#202020] border-b border-neutral-700 focus:border-gold-400 text-white py-3 px-4 text-sm outline-none transition-all focus:ring-1 focus:ring-gold-500/10"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-3xs uppercase text-neutral-400 font-bold block">Email Address (Optional)</label>
                    <input 
                      type="email" 
                      placeholder="e.g., design@bhavik.com"
                      value={formInquiry.email}
                      onChange={(e) => setFormInquiry(prev => ({ ...prev, email: e.target.value }))}
                      className="w-full bg-[#202020] border-b border-neutral-700 focus:border-gold-400 text-white py-3 px-4 text-sm outline-none transition-all focus:ring-1 focus:ring-gold-500/10"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-3xs uppercase text-neutral-400 font-bold block">Design Category</label>
                    <select
                      value={formInquiry.service}
                      onChange={(e) => setFormInquiry(prev => ({ ...prev, service: e.target.value }))}
                      className="w-full bg-[#202020] border-b border-neutral-700 focus:border-gold-400 text-white py-3 px-4 text-sm outline-none transition-all cursor-pointer"
                    >
                      <option value="Interior Design">Interior Design</option>
                      <option value="Exterior Design">Exterior Design</option>
                      <option value="Building Design">Building Design</option>
                      <option value="Modular Kitchen">Modular Kitchen</option>
                      <option value="Living Room Design">Living Room Design</option>
                      <option value="Bedroom Design">Bedroom Design</option>
                      <option value="Office Interiors">Office Interiors</option>
                      <option value="Renovation">Renovation & Remodeling</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-3xs uppercase text-neutral-400 font-bold block">Budget Package Spec Selected</label>
                  <input 
                    type="text" 
                    placeholder="2 BHK Premium Interior Package"
                    value={formInquiry.packageType}
                    onChange={(e) => setFormInquiry(prev => ({ ...prev, packageType: e.target.value }))}
                    className="w-full bg-[#202020] border-b border-neutral-700 focus:border-gold-400 text-white py-3 px-4 text-sm outline-none transition-all"
                  />
                  <span className="text-3xs text-neutral-500 uppercase block">Tip: Calibrate your estimated pricing using our interactive customizer above first!</span>
                </div>

                <div className="space-y-2">
                  <label className="text-3xs uppercase text-neutral-400 font-bold block">Special Space Requests or Dimensions</label>
                  <textarea 
                    rows={3}
                    placeholder="List details (e.g., prefers modern styling, fluted wood paneling backdrops, particular walnut furniture specs, modular kitchen addon selections)"
                    value={formInquiry.specialRequests}
                    onChange={(e) => setFormInquiry(prev => ({ ...prev, specialRequests: e.target.value }))}
                    className="w-full bg-[#202020] border-b border-neutral-700 focus:border-gold-400 text-white py-3.5 px-4 text-sm outline-none transition-all"
                  />
                </div>

                <div className="pt-4">
                  <button 
                    type="submit" 
                    disabled={loadingForm || formSuccess}
                    className="w-full py-4 bg-gold-400 text-charcoal-950 font-extrabold text-xs uppercase tracking-widest hover:bg-white hover:text-charcoal-950 transition-all rounded-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {loadingForm ? 'Scheduling Workspace...' : formSuccess ? 'Consultation Request Saved!' : 'Secure Free Consultation Session'}
                    {!loadingForm && !formSuccess && <Send className="w-3.5 h-3.5" />}
                    {formSuccess && <Check className="w-4 h-4 text-charcoal-950" />}
                  </button>
                </div>

                <AnimatePresence>
                  {formSuccess && (
                    <motion.div 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="p-4 bg-green-950/40 border border-green-800 text-green-400 text-xs rounded-sm text-center leading-normal"
                    >
                      **Success!** Your luxury spatial consultation request has been stored. You can review and verify your inquiry live in the **CRM Leads Log** button on the top-left side workspace!
                    </motion.div>
                  )}
                </AnimatePresence>

              </form>
            </div>

          </div>
        </section>

      </main>

      {/* Dynamic Drawer AI Stylist Chat (Aria) */}
      <AnimatePresence>
        {chatOpen && (
          <motion.div
            initial={{ opacity: 0, x: 200 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 200 }}
            className="fixed top-0 right-0 w-full sm:w-[450px] h-full bg-neutral-900 border-l border-neutral-800 text-white z-50 shadow-2xl flex flex-col justify-between"
          >
            {/* Chat Drawer Header */}
            <div className="p-5 border-b border-neutral-800 bg-neutral-950 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="relative w-9 h-9 rounded-full bg-gold-400 flex items-center justify-center text-charcoal-950 font-serif font-black text-sm">
                  A
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border border-neutral-900 rounded-full"></span>
                </div>
                <div>
                  <span className="font-serif text-sm font-bold block text-white">Aria</span>
                  <span className="text-[10px] text-neutral-400 uppercase tracking-widest block font-bold">Afkain Lead space stylist</span>
                </div>
              </div>
              <button onClick={() => setChatOpen(false)} className="text-neutral-400 hover:text-white cursor-pointer select-none p-1 bg-neutral-850 hover:bg-neutral-800 rounded-full transition-all">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Message Lists Wrapper */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#141414] no-scrollbar">
              {chatMessages.map((msg, index) => (
                <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`p-4 max-w-[85%] text-xs leading-relaxed rounded-lg ${msg.role === 'user' ? 'bg-gold-500 text-charcoal-950 font-semibold rounded-br-none' : 'bg-neutral-850 text-neutral-100 rounded-bl-none border border-neutral-800'}`}>
                    {msg.role === 'assistant' && (
                      <span className="text-[9px] uppercase tracking-wider text-gold-400 font-extrabold block mb-1">
                        Aria (Design Lead)
                      </span>
                    )}
                    <p className="whitespace-pre-line">{msg.content}</p>
                  </div>
                </div>
              ))}
              
              {aiTyping && (
                <div className="flex justify-start">
                  <div className="p-4 bg-neutral-850 border border-neutral-800 text-neutral-400 text-xs rounded-lg rounded-bl-none flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold text-gold-400 animate-pulse">Aria is sketching designs...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Chat Quick prompt tags */}
            <div className="p-3 bg-neutral-950 border-t border-neutral-850 overflow-x-auto no-scrollbar flex gap-2">
              {[
                'Living room accent options',
                'Explain 2 BHK package specs',
                'What is the Turnkey solution timeline?',
                'Best colors for low-light rooms?'
              ].map((txt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQuickPrompt(txt)}
                  className="px-3 py-1.5 bg-neutral-850 border border-neutral-800 rounded-full text-3xs text-neutral-300 whitespace-nowrap hover:bg-gold-500 hover:text-charcoal-950 transition-all cursor-pointer font-semibold uppercase tracking-wider shrink-0"
                >
                  {txt}
                </button>
              ))}
            </div>

            {/* Chat Input Field form toolbar */}
            <form onSubmit={handleSendChatMessage} className="p-4 bg-neutral-950 border-t border-neutral-850 flex gap-2">
              <input
                type="text"
                placeholder="Ask Aria about spatial layouts, materials, or packages..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                className="flex-1 bg-neutral-850 text-xs text-white placeholder-neutral-500 py-3 px-4 outline-none border border-neutral-800 rounded-sm focus:border-gold-500 focus:ring-1 focus:ring-gold-500/15"
              />
              <button 
                type="submit"
                className="p-3 bg-gold-400 text-charcoal-950 hover:bg-white transition-all rounded-sm cursor-pointer"
              >
                <Send className="w-4 h-4 text-charcoal-950" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CRM Admin lead inquiries workspace logs (The Developer CRM Interface) */}
      <AnimatePresence>
        {leadDetailOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-[#181818] border border-neutral-800 text-white p-6 md:p-8 max-w-4xl w-full rounded-lg shadow-2xl flex flex-col h-[85vh] justify-between"
            >
              <div>
                <div className="flex justify-between items-center pb-4 border-b border-neutral-800 mb-6">
                  <div className="flex items-center gap-2">
                    <Database className="w-5 h-5 text-gold-400 animate-spin" />
                    <div>
                      <h3 className="font-serif text-lg font-bold">Afkain Leads & Inquiries Workspace CRM</h3>
                      <span className="text-3xs text-neutral-400 uppercase tracking-widest font-black block">Persistent Database Mock Panel</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => { setLeadDetailOpen(false); setActiveLead(null); }}
                    className="text-neutral-400 hover:text-white p-1.5 bg-neutral-850 hover:bg-neutral-800 rounded-full cursor-pointer transition-all"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 overflow-hidden max-h-[60vh]">
                  
                  {/* Left List */}
                  <div className="md:col-span-5 space-y-3 overflow-y-auto pr-2 no-scrollbar border-r border-neutral-850">
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-extrabold block mb-2">Submitted Inquiries:</span>
                    {leads.length === 0 ? (
                      <p className="text-xs text-neutral-500 italic py-4">No lead entries registered. Submit the bottom contact form to test workspace persist!</p>
                    ) : (
                      leads.map((item) => (
                        <div 
                          key={item.id}
                          onClick={() => setActiveLead(item)}
                          className={`p-3 border rounded-sm cursor-pointer transition-all ${activeLead?.id === item.id ? 'bg-[#252525] border-gold-400/50' : 'bg-[#1e1e1e] border-neutral-800 hover:border-neutral-700'}`}
                        >
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-xs font-bold text-neutral-100">{item.name}</span>
                            <span className="text-[9px] font-black uppercase text-gold-400">{item.id}</span>
                          </div>
                          
                          <div className="flex justify-between items-center text-3xs text-neutral-400">
                            <span>{item.service} | {item.date}</span>
                            <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold ${
                              item.status === 'Pending' ? 'bg-yellow-950/40 border border-yellow-700 text-yellow-500' :
                              item.status === 'Scheduled' ? 'bg-blue-950/40 border border-blue-700 text-blue-500' :
                              item.status === 'Designing' ? 'bg-purple-950/40 border border-purple-700 text-purple-500' :
                              'bg-green-950/40 border border-green-700 text-green-500'
                            }`}>
                              {item.status}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Right Detail Detail Panel */}
                  <div className="md:col-span-7 bg-[#1c1c1c] p-5 border border-neutral-800 rounded-sm overflow-y-auto no-scrollbar flex flex-col justify-between">
                    {activeLead ? (
                      <div className="space-y-4">
                        <div className="flex justify-between items-start pb-3 border-b border-neutral-850">
                          <div>
                            <span className="text-3xs uppercase font-extrabold text-[#fed65b] block">ACTIVE LEAD</span>
                            <h4 className="text-sm font-bold text-white">{activeLead.name}</h4>
                          </div>
                          <span className="text-xs text-gold-400 font-serif font-black">{activeLead.id}</span>
                        </div>

                        <div className="grid grid-cols-2 gap-3 text-2xs uppercase tracking-wider text-neutral-400">
                          <div>
                            <span className="text-3xs text-neutral-500 block mb-1">Phone:</span>
                            <span className="text-neutral-100 font-semibold">{activeLead.phone}</span>
                          </div>
                          <div>
                            <span className="text-3xs text-neutral-500 block mb-1">Email:</span>
                            <span className="text-neutral-100 font-semibold break-all">{activeLead.email}</span>
                          </div>
                          <div>
                            <span className="text-3xs text-neutral-500 block mb-1">Package Category:</span>
                            <span className="text-neutral-100 font-semibold">{activeLead.packageType}</span>
                          </div>
                          <div>
                            <span className="text-3xs text-neutral-500 block mb-1">Category Service:</span>
                            <span className="text-neutral-100 font-semibold">{activeLead.service}</span>
                          </div>
                          <div>
                            <span className="text-3xs text-neutral-500 block mb-1">Budget Valuated:</span>
                            <span className="text-gold-400 font-black">{activeLead.budgetEst}</span>
                          </div>
                          <div>
                            <span className="text-3xs text-neutral-500 block mb-1">Registered:</span>
                            <span className="text-neutral-300 font-semibold">{activeLead.date}</span>
                          </div>
                        </div>

                        {activeLead.specialRequests && (
                          <div className="p-3 bg-neutral-900 border border-neutral-850 rounded-sm">
                            <span className="text-3xs uppercase tracking-widest text-neutral-500 block mb-1">Notes / Requests:</span>
                            <p className="text-neutral-300 text-xs leading-normal">{activeLead.specialRequests}</p>
                          </div>
                        )}

                        <div className="space-y-2 pt-4 border-t border-neutral-850">
                          <span className="text-3xs uppercase text-neutral-400 font-bold block mb-2">Leads CRM Status Manager:</span>
                          <div className="flex flex-wrap gap-2">
                            {(['Pending', 'Scheduled', 'Designing', 'Completed'] as const).map((st) => (
                              <button
                                key={st}
                                onClick={() => handleInquiryStatusChange(activeLead.id, st)}
                                className={`px-3 py-1.5 rounded-sm text-3xs uppercase font-extrabold tracking-widest transition-all cursor-pointer ${activeLead.status === st ? 'bg-gold-500 text-charcoal-950 font-black' : 'bg-[#222] text-neutral-400 hover:text-white'}`}
                              >
                                {st}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="pt-4 border-t border-neutral-850 flex justify-end">
                          <button 
                            onClick={() => handleInquiryDelete(activeLead.id)}
                            className="px-4 py-2 border border-red-500 text-red-500 text-3xs font-extrabold uppercase tracking-widest hover:bg-red-950 hover:border-red-400 rounded-sm cursor-pointer transition-colors"
                          >
                            Delete Inquiry Entry
                          </button>
                        </div>

                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-20 text-center opacity-60">
                        <Sliders className="w-12 h-12 text-neutral-600 mb-4" />
                        <span className="text-xs uppercase tracking-widest font-bold">Select an inquiry item to view detail specs</span>
                      </div>
                    )}
                  </div>

                </div>
              </div>

              <div className="pt-4 border-t border-neutral-850 flex justify-between items-center text-3xs text-neutral-500 uppercase tracking-wider">
                <span>Afkain DB Admin Workspace | Persistent Leads CRM Module</span>
                <span>Active Leads: {leads.length}</span>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Classic Multi-Column Luxury Dark Footer */}
      <footer className="w-full bg-charcoal-900 text-white border-t border-charcoal-800 relative z-10">
        <div className="max-w-[1440px] mx-auto px-6 md:px-20 py-20 grid grid-cols-1 md:grid-cols-12 gap-12">
          
          <div className="col-span-1 md:col-span-5 space-y-6">
            <span className="font-serif text-2xl font-bold tracking-tight text-white block">
              Afkain <span className="text-gold-500">Interior</span>
            </span>
            <p className="text-neutral-400 text-xs md:text-sm leading-relaxed max-w-sm">
              Crafting premium residential elevation architecture and gorgeous bespoke turnkey interiors across Ahmedabad, Gomtipur, South Bopal, and Nikol. Delivering luxury design since 2021.
            </p>
            <p className="text-neutral-500 text-3xs uppercase tracking-widest">
              © 2026 Afkain Interior Designer. Licensed in Ahmedabad, Gujarat. All rights reserved.
            </p>
          </div>

          <div className="col-span-1 md:col-span-2.5 space-y-4">
            <h5 className="font-serif text-sm font-bold text-[#ffe088] uppercase tracking-widest mb-2">Explore</h5>
            <ul className="space-y-2 text-xs md:text-sm text-neutral-300">
              <li><a className="hover:text-gold-400 transition-colors" href="#home" onClick={() => setActiveSection('home')}>Home Overview</a></li>
              <li><a className="hover:text-gold-400 transition-colors" href="#about" onClick={() => setActiveSection('about')}>Studio Story</a></li>
              <li><a className="hover:text-gold-400 transition-colors" href="#services" onClick={() => setActiveSection('services')}>Specialties</a></li>
              <li><a className="hover:text-gold-400 transition-colors" href="#packages" onClick={() => setActiveSection('packages')}>Pricing Packages</a></li>
              <li><a className="hover:text-gold-400 transition-colors" href="#portfolio" onClick={() => setActiveSection('portfolio')}>Design Portfolio</a></li>
            </ul>
          </div>

          <div className="col-span-1 md:col-span-2.5 space-y-4">
            <h5 className="font-serif text-sm font-bold text-[#ffe088] uppercase tracking-widest mb-2">Our Services</h5>
            <ul className="space-y-2 text-xs md:text-sm text-neutral-300">
              <li><a className="hover:text-gold-400 transition-colors" href="#services">Modular Kitchens</a></li>
              <li><a className="hover:text-gold-400 transition-colors" href="#services">Luxury Living Rooms</a></li>
              <li><a className="hover:text-gold-400 transition-colors" href="#services">Bespoke Bedrooms</a></li>
              <li><a className="hover:text-gold-400 transition-colors" href="#services">Residential Facades</a></li>
              <li><a className="hover:text-gold-400 transition-colors" href="#services">Commercial Offices</a></li>
            </ul>
          </div>

          <div className="col-span-1 md:col-span-2 space-y-4">
            <h5 className="font-serif text-sm font-bold text-[#ffe088] uppercase tracking-widest mb-2">Contact Details</h5>
            <ul className="space-y-3.5 text-xs text-neutral-300 font-semibold tracking-wider">
              <li className="flex gap-2 text-3xs font-light tracking-wide uppercase text-neutral-400">
                <MapPin className="w-4 h-4 text-gold-400 shrink-0" />
                <span>Gomtipur, Ahmedabad, Gujarat 380021</span>
              </li>
              <li className="flex gap-2">
                <Phone className="w-4 h-4 text-gold-400 shrink-0" />
                <a className="hover:text-gold-400 font-bold text-white transition-colors" href="tel:08488095593">084880 95593</a>
              </li>
              <li>
                <button 
                  onClick={() => setChatOpen(true)}
                  className="px-3.5 py-1.5 bg-neutral-850 hover:bg-gold-500 hover:text-charcoal-900 border border-neutral-800 text-gold-400 rounded-sm text-3xs transition-all flex items-center gap-1 cursor-pointer font-bold uppercase tracking-wider"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Chat With Aria
                </button>
              </li>
            </ul>
          </div>

        </div>
      </footer>

    </div>
  );
}
