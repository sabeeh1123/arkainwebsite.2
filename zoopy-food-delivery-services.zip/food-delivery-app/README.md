# Zoopy Food Delivery Services

A responsive food-delivery application built with HTML, CSS, vanilla JavaScript and Node.js/Express. It includes menu browsing, search, category filters, a persistent cart, checkout, secure accounts and PostgreSQL persistence.

## Requirements

- Node.js 18 or newer
- npm
- PostgreSQL 14 or newer
- Optional: Docker Desktop for the quickest PostgreSQL setup
- pgAdmin for graphical database management

## Quick setup with Docker

1. Open a terminal in this folder.
2. Create the local environment file:

       Copy-Item .env.example .env

3. Start PostgreSQL:

       npm run db:up

4. Install dependencies and start Zoopy:

       npm install
       npm start

5. Visit http://localhost:3000.

The backend automatically creates the users, sessions, and orders tables the first time it connects.


## Manual setup with PostgreSQL and pgAdmin

If PostgreSQL is already installed, connect pgAdmin to your local PostgreSQL server and open the Query Tool on the postgres database. Run these statements using a password of your choice:

    CREATE ROLE zoopy WITH LOGIN PASSWORD 'your_secure_password';
    CREATE DATABASE zoopy_food OWNER zoopy;

Copy .env.example to .env and update the password in DATABASE_URL. Start the app with npm start. Zoopy creates its tables automatically.

You can also open database/schema.sql in pgAdmin Query Tool and execute it while connected to zoopy_food.
## Connect with pgAdmin

Register a new server in pgAdmin using:

- **Name:** Zoopy Food Delivery
- **Host:** localhost
- **Port:** 5432
- **Maintenance database:** zoopy_food
- **Username:** zoopy
- **Password:** zoopy_dev_password

Then expand:

    Servers
    └── Zoopy Food Delivery
        └── Databases
            └── zoopy_food
                └── Schemas
                    └── public
                        └── Tables

Right-click a table and select **View/Edit Data → All Rows**.

For production, replace the development password in both .env and docker-compose.yml, or point DATABASE_URL at your managed PostgreSQL database.

## Use an existing PostgreSQL server

Copy .env.example to .env and replace DATABASE_URL:

    DATABASE_URL=postgresql://USERNAME:PASSWORD@HOST:5432/DATABASE_NAME
    DATABASE_SSL=false
    PORT=3000

Use DATABASE_SSL=true when your hosted provider requires TLS.

## Database tables

- users — names, emails and secure password hashes
- sessions — HTTP-only login sessions
- orders — customers, JSON order items, payment choice and totals

Useful pgAdmin queries:

    SELECT id, name, email, created_at FROM users ORDER BY created_at DESC;
    SELECT id, user_id, status, total, created_at FROM orders ORDER BY created_at DESC;

## API

- GET /api/health checks the PostgreSQL connection.
- GET /api/menu returns the menu.
- POST /api/auth/register creates an account.
- POST /api/auth/login signs in.
- POST /api/auth/logout signs out.
- GET /api/auth/me returns the active account.
- POST /api/orders validates, prices and saves an order.

Passwords are hashed with Node.js scrypt. Sessions use HTTP-only cookies. Prices are recalculated by the server rather than trusted from the browser.

## Project structure

- server.js — Express API and PostgreSQL queries
- docker-compose.yml — local PostgreSQL service
- .env.example — database connection template
- public/ — responsive storefront, login and checkout

- database/schema.sql — PostgreSQL schema for pgAdmin Query Tool

