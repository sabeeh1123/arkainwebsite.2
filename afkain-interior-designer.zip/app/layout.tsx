import type {Metadata} from 'next';
import { Playfair_Display, Manrope } from 'next/font/google';
import './globals.css'; // Global styles

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
});

const manrope = Manrope({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Afkain Interior Designer | Luxury Interior & Exterior Design Ahmedabad',
  description: 'Premium interior and exterior design solutions in Gomtipur, Ahmedabad, Gujarat. Specializing in luxury residential, commercial, modular kitchens, and turnkey interior solutions.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${playfair.variable} ${manrope.variable} scroll-smooth`}>
      <body className="bg-neutral-50 text-charcoal-800 font-sans antialiased selection:bg-gold-100 selection:text-gold-900" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}

